paperspace v2.0.8 猫咪可选主题

本包是官网第四展示风格，通过v2.0.8已有的JSON catalog稳定style_id=web-cat及主页skin实现，不是固件新增内置枚举。原三套主题保留。猫咪画作由本轮用户授权imagegen原创生成，仅裁去透明留白、等比缩放、白底与16灰阶规范化；没有重画、加字或网页覆盖。

它与“最小SD资源包”分开：本包只带猫咪背景、主页艺术theme/art和含原六布局加猫咪两布局的catalog.json；不重复原六背景，不含字体、任何书籍/封面、缓存、个人settings或主页配置。每书封面来自该书自身，不随主题打包。

安装前先解压到电脑新目录，核对SHA256SUMS。把paperspace下资源合并到SD根，最终是/paperspace/resources/lockscreen/web-cat.plbg等路径，不要多套包名目录。
首次空白卡可采用本包catalog.json。已有/paperspace/resources/lockscreen/catalog.json时必须保留并先备份；已有自定义风格时不要用本包整份文件覆盖，应通过现有主题工具合并web-cat的两条profile（原有profile不删）。不提供自动覆盖或安装程序。原六主题的图像如需要请另装最小SD包；缺少时原固件按缺图白底规则显示。

安全弹出、装回、重启，然后在设置→外观→锁屏中预览并主动启用“猫咪 · paperspace”。主页装饰目录是/paperspace/resources/widgets/themes/web-cat；可在现有主页小组件外观/跟随锁屏风格中主动选择使用。本包不会改变个人主页排序、阅读字号、日夜状态或任何现有settings；官网演示使用的cat.bin并未放入SD包。

内置救援字体可显示固定标签，黄历部分中文可能缺字并明确提示。完整黄历需用户主动选择覆盖所需中文的合法TTF，本包不指定必需字体、不捆绑26MB官网字体。字体如需要可单独下载官网精确原OFL字体和许可，放入SD自选路径，再到系统字体中浏览选择。不要为了主题覆盖原个人字体文件。

许可/来源见CAT-ARTWORK-NOTICE.txt及资源清单。适用来源commit 79f2f5ad303b9a588d551e3e0eb4b6e5735bc56b；Linux host/browser原帧验证不能替代实体卡/阅读器。无真实SD写入。
