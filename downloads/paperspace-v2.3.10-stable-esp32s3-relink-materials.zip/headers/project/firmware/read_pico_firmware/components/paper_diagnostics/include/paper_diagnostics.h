/* SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#ifdef ESP_PLATFORM
#include "esp_attr.h"
#else
#ifndef IRAM_ATTR
#define IRAM_ATTR
#endif
#endif
#ifdef __cplusplus
extern "C" {
#endif
// Defaults to off, including before settings are available. No settings/I/O/clock access.
bool IRAM_ATTR paper_diagnostics_enabled(void);
uint32_t IRAM_ATTR paper_diagnostics_epoch(void);
// Main task, after successful settings load/save. SDK logging is filtered before arguments.
void paper_diagnostics_set_enabled(bool enabled);
#ifdef __cplusplus
}
#endif

// Only for optional observational timestamps, never deadlines or hardware sequencing.
#define PAPER_DIAG_TIME_US() (paper_diagnostics_enabled()?esp_timer_get_time():0)
