PaperSpace 2.3.10 stable LGPL relink materials

Requires ESP-IDF toolchain esp-15.2.0_20251204 (Xtensa), Python with esptool 5.4.0. Install the official ESP-IDF 6.1 toolchain for your platform.
The proprietary application is provided as relinkable object code, not source.

Verify: python relink.py --toolchain-bin /path/to/xtensa-esp-elf/bin --verify-only
Baseline: python relink.py --toolchain-bin /path/to/xtensa-esp-elf/bin --python /path/to/idf-python --output /new/baseline
Modify sources/epdiy as needed, then: python relink.py --toolchain-bin /path/to/xtensa-esp-elf/bin --python /path/to/idf-python --output /new/modified --rebuild-epdiy
Outputs retain official flash layout. User installation is optional and at own risk; hardware tests NOT_RUN. No secure boot or encryption enabled in this configuration.
