/* 普通操作提示的单调时钟生命周期；任务进度和页面信息由各自模型持有。
 * Monotonic lifetime for operation notices; task progress and page information own their models. */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

#define UI_NOTICE_CHARS 20u
#define UI_NOTICE_TEXT_BYTES (UI_NOTICE_CHARS*4u+1u)
#define UI_NOTICE_DURATION_MS 5000u

typedef struct {
    uint64_t started_ms; ///< 单调发布时刻 / Monotonic publication time
    bool active; ///< 是否有提示 / Whether a notice was published
    bool fresh; ///< 本次事务产生结果 / Result published in this transaction
} ui_notice_t;

// 每个输入或tick开始独立事务；不改变有效提示的原截止时刻。
// Begin an input/tick transaction without changing the active notice deadline.
static inline void ui_notice_begin(ui_notice_t* n) {n->fresh=false;}
static inline void ui_notice_publish(ui_notice_t* n,int64_t now_ms) {
    n->started_ms=(uint64_t)now_ms;n->active=true;n->fresh=true;
}
static inline void ui_notice_clear(ui_notice_t* n) {n->active=false;n->fresh=false;}
static inline bool ui_notice_expired(const ui_notice_t* n,int64_t now_ms) {
    // 无符号差值支持时钟回绕；时钟复位也让旧提示失效。/ Unsigned elapsed time handles wrap; a reset expires stale notices.
    return n->active&&(uint64_t)now_ms-n->started_ms>=UI_NOTICE_DURATION_MS;
}

/// 有界、完整UTF-8、最多20字；可用真实字宽追加省略号，允许原地收敛。
/// Bounded complete UTF-8, at most twenty characters; optional measured fitting, including in place.
static inline void ui_notice_fit(char* out,size_t capacity,const char* text,
                                 int px,int width,int (*measure)(int,const char*)) {
    if(!capacity)return;
    const size_t length=strnlen(text,UI_NOTICE_TEXT_BYTES);
    size_t used=0;unsigned chars=0;
    while(used<length&&chars<UI_NOTICE_CHARS) {
        const unsigned char c=(unsigned char)text[used];
        size_t bytes=c<0x80?1:c>=0xc2&&c<=0xdf?2:c>=0xe0&&c<=0xef?3:c>=0xf0&&c<=0xf4?4:0;
        if(!bytes||used+bytes>length||used+bytes>=capacity)break;
        uint32_t cp=c&((1u<<(8u-(unsigned)bytes-1u))-1u);
        if(bytes==1)cp=c;
        bool valid=true;
        for(size_t i=1;i<bytes;i++) {
            const unsigned char next=(unsigned char)text[used+i];
            if((next&0xc0)!=0x80){valid=false;break;}
            cp=(cp<<6)|(next&0x3f);
        }
        if(!valid||cp<32||cp==127||(bytes==2&&cp<0x80)||(bytes==3&&cp<0x800)||
           (bytes==4&&cp<0x10000)||(cp>=0xd800&&cp<=0xdfff)||cp>0x10ffff)break;
        used+=bytes;chars++;
    }
    bool shortened=used<length;
    memmove(out,text,used);out[used]=0;
    while((shortened&&(chars>UI_NOTICE_CHARS-3u||used+4u>capacity))||
          (measure&&measure(px,out)>width)) {
        shortened=true;
        if(!chars){out[0]=0;return;}
        used--;while(used&&((unsigned char)out[used]&0xc0)==0x80)used--;
        out[used]=0;chars--;
    }
    if(shortened) {
        if(used+4u>capacity){out[0]=0;return;}
        memcpy(out+used,"...",4);
        while(measure&&measure(px,out)>width) {
            if(!chars){out[0]=0;return;}
            used--;while(used&&((unsigned char)out[used]&0xc0)==0x80)used--;
            chars--;memcpy(out+used,"...",4);
        }
    }
}
