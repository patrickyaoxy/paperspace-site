#!/usr/bin/env python3
"""使用公开对象及精确参数重链；只重编 epdiy，不构建应用。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--toolchain-bin', required=True, type=Path)
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--rebuild-epdiy', action='store_true')
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    plan = json.loads((root / 'relink-plan.json').read_text())
    manifest = json.loads((root / 'materials-manifest.json').read_text())
    for name, entry in manifest['files'].items():
        path = root / name
        if not path.is_file() or sha(path) != entry['sha256']:
            # 编辑库源/头文件是明确支持的用途；原始状态核验仍会标记。
            if not args.rebuild_epdiy or not name.startswith(('sources/epdiy/', 'headers/')):
                raise SystemExit('材料缺失或摘要不符: ' + name)
    if args.verify_only:
        print('所有材料 SHA-256 校验通过')
        return
    if args.output is None:
        parser.error('实际重链需要 --output')
    toolbin = args.toolchain_bin.resolve(strict=True)
    compiler = toolbin / plan['compiler']
    version = subprocess.check_output([str(compiler), '--version'], text=True)
    if version != plan['compiler_version']:
        raise SystemExit('编译器版本不匹配')
    esptool_version = subprocess.check_output([args.python, '-c', 'import esptool;print(esptool.__version__)'], text=True).strip()
    if esptool_version != plan['esptool_version']:
        raise SystemExit('esptool 版本不匹配')
    for item in plan['implicit_toolchain_inputs']:
        suffix = item['path'].removeprefix('@ROOT@/toolchain/')
        if sha(toolbin.parent / suffix) != item['sha256']:
            raise SystemExit('工具链运行库摘要不符: ' + item['name'])
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    work = out / 'work'
    shutil.copytree(root / 'build', work)
    logs = out / 'logs'
    logs.mkdir()
    replacements = {'@ROOT@': str(root), '@WORK@': str(work), '@OUT@': str(out),
                    '@TOOLBIN@': str(toolbin), '@PYTHON@': args.python}
    def expand(argv):
        result = []
        for arg in argv:
            for old, new in replacements.items():
                arg = arg.replace(old, new)
            result.append(arg)
        return result
    commands = []
    def run(label, argv, cwd=work):
        command = expand(argv)
        with (logs / (label + '.log')).open('wb') as stream:
            result = subprocess.run(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT)
        commands.append({'label': label, 'argv': argv, 'exit_code': result.returncode})
        write(out / 'commands.json', commands)
        if result.returncode:
            raise SystemExit('执行失败，保留日志: ' + str(logs / (label + '.log')))
    if args.rebuild_epdiy:
        for index, entry in enumerate(plan['epdiy_compiles']):
            Path(str(entry['output']).replace('@WORK@', str(work))).parent.mkdir(parents=True, exist_ok=True)
            run('epdiy-%02d' % index, entry['argv'])
            run('epdiy-strip-%02d' % index, ['@TOOLBIN@/' + plan['strip'], '--strip-debug', entry['output']])
        archive = work / plan['epdiy_archive']
        archive.unlink(missing_ok=True)
        run('epdiy-ar', ['@TOOLBIN@/' + plan['ar'], 'qcD', str(archive)] + [e['output'] for e in plan['epdiy_compiles']])
        run('epdiy-ranlib', ['@TOOLBIN@/' + plan['ranlib'], str(archive)])
    run('link', plan['link_argv'])
    run('elf2image', plan['elf2image_argv'])
    app = (out / 'Read_Pico.bin').read_bytes()
    if plan.get('channel') == 'stable':
        expected_channel = (b'PAPERCH\0', 1, 32, 2, bytes(3), 0x10000, 1, 0, 0)
        if (app[48:80].split(b'\0')[0].decode() != plan['version'] or
                struct.unpack_from('<8sHHB3sIIII', app, 288) != expected_channel):
            raise SystemExit('输出镜像的版本或正式渠道记录不符')
    artifacts = {name: {'sha256': sha(out / name), 'bytes': (out / name).stat().st_size}
                 for name in plan['artifacts']}
    equal = (all(artifacts[name]['sha256'] == plan['reference'][name]['sha256'] for name in artifacts)
             if plan['reference'] else None)
    write(out / 'result.json', {'schema': 1, 'source_sha': plan['source_sha'],
          'rebuild_epdiy': args.rebuild_epdiy, 'reference_equal': equal, 'artifacts': artifacts,
          'device': 'NOT_RUN'})
    print(json.dumps({'reference_equal': equal, 'artifacts': artifacts}, ensure_ascii=False, indent=2))
    if not args.rebuild_epdiy and equal is False:
        raise SystemExit('基线重链与正式参考镜像不完全相同')


if __name__ == '__main__':
    main()
