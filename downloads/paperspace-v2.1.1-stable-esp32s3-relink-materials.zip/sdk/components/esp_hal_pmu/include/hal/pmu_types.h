/*
 * SPDX-FileCopyrightText: 2023-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

#include <stdint.h>
#include "soc/soc.h"
#include "soc/soc_caps.h"
#include "hal/config.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief PMU modes of HP system
 */
typedef enum {
    PMU_MODE_HP_ACTIVE = 0, /*!< PMU in HP_ACTIVE mode */
    PMU_MODE_HP_MODEM,      /*!< PMU in HP_MODEM mode */
    PMU_MODE_HP_SLEEP,      /*!< PMU in HP_SLEEP mode */
    PMU_MODE_HP_MAX,
} pmu_hp_mode_t;

/**
 * @brief PMU ICG modem code of HP system
 *
 * Each code maps to one bit in modem_lpcon `clk_*_st_map` bitmap fields.
 */
typedef enum {
    PMU_HP_ICG_MODEM_CODE_SLEEP = 0,  /*!< ICG bitmap bit for HP_SLEEP mode */
    PMU_HP_ICG_MODEM_CODE_MODEM = 1,  /*!< ICG bitmap bit for HP_MODEM mode */
    PMU_HP_ICG_MODEM_CODE_ACTIVE = 2, /*!< ICG bitmap bit for HP_ACTIVE mode */
} pmu_hp_icg_modem_mode_t;

/**
 * @brief PMU modes of LP system
 */
typedef enum {
    PMU_MODE_LP_ACTIVE = 0, /*!< PMU in LP_ACTIVE mode */
    PMU_MODE_LP_SLEEP,      /*!< PMU in LP_SLEEP mode */
    PMU_MODE_LP_MAX,
} pmu_lp_mode_t;

/**
 * @brief PMU power domain of HP system
 */
#if SOC_IS(ESP32P4)
typedef enum {
    PMU_HP_PD_TOP = 0,      /*!< Power domain of digital top */
    PMU_HP_PD_CNNT = 1,     /*!< Power domain of high-speed IO peripherals such as USB/SDIO/Ethernet etc.*/
    PMU_HP_PD_HPMEM = 2,
    PMU_HP_PD_CPU = 3,
} pmu_hp_power_domain_t;
#elif SOC_IS(ESP32S31)
typedef enum {
    PMU_HP_PD_TOP = 0,      /*!< Power domain of digital top */
    PMU_HP_PD_HPALIVE,
    PMU_HP_PD_MODEMPWR,
    PMU_HP_PD_HPCPU,
    PMU_HP_PD_HPCNNT,
    PMU_HP_PD_MODEM
} pmu_hp_power_domain_t;
#else
typedef enum {
    PMU_HP_PD_TOP = 0,      /*!< Power domain of digital top */
#if SOC_PM_SUPPORT_HP_AON_PD
    PMU_HP_PD_HP_AON = 1,   /*!< Power domain of always-on */
#endif
    PMU_HP_PD_CPU = 2,      /*!< Power domain of HP CPU */
    PMU_HP_PD_RESERVED = 3, /*!< Reserved power domain */
    PMU_HP_PD_WIFI = 4,     /*!< Power domain of WIFI */
    PMU_HP_PD_BT_154 = PMU_HP_PD_WIFI,   /*!< Power domain of BT 154 */
} pmu_hp_power_domain_t;
#endif

#ifdef __cplusplus
}
#endif
