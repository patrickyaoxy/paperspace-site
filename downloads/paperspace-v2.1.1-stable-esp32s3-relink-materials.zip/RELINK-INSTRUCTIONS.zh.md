# paperspace 2.1.1 正式功能渠道：Linux 重链接材料

本材料是源码 `3abe593b3ad208229aaf734b879af2f5081c6cec`、tree `740fff5158b13aeb4d9eed7f6dfedb74457b7aef` 的全新 ESP32-S3 stable 云构建。SDK为官方ESP-IDF v6.1，精确提交 `fff9895c82d744c7237be8847347bdd1b07c6643`。正式功能渠道与发布/真机验收阶段分开；本材料没有把未测项改称通过。

没有使用标签曾描述的本地app（3335968字节/ef2c…），也没有使用2.0.8应用对象。当前规范化BIN是3338288字节，SHA-256：

`3bd0d10257bdad0020bc72ee7c4f37c0e3d26e2be41132a41f3c7ba4b34e7310`

应用私有C/C++源码没有包含；提供当前应用编译对象、SDK链接输入、修改版 LGPL epdiy 完整源与实际重编参数。对象保留符号/重定位并去除DWARF，ELF由链接器 `--strip-debug` 直接生成；没有修改BIN摘要或二进制字符串。`materials-manifest.json` 是逐文件长度/hash清单，`verification.json` 记录实际验证范围。

## 准备环境

已在Linux x86-64及Python3.12验证；其他系统/架构未验证。下载官方 [Xtensa工具链 esp-15.2.0_20251204](https://github.com/espressif/crosstool-NG/releases/download/esp-15.2.0_20251204/xtensa-esp-elf-15.2.0_20251204-x86_64-linux-gnu.tar.xz)，归档SHA-256必须是 `3d50f5cd5f173acfd524e07c1cd69bc99585731a415ca2e5bce879997fe602b8`。解压后把 `xtensa-esp-elf/bin` 路径记作 `$TCBIN`。

安装图像工具：`python3 -m venv .venv`，然后 `.venv/bin/python -m pip install -r requirements-relink.txt`。不需要完整私有源码、原构建目录或CMake/Ninja；匹配工具链仍提供内部头/specs/运行库。工具会核编译器/esptool版本及实际隐式运行库SHA。包内的runtime库副本仅供输入审计；实际GCC默认库来自匹配官方工具链并逐项核原hash。

保留原解压副本。`python3 relink.py --toolchain-bin "$TCBIN" --verify-only` 核原始材料摘要；此模式不需要esptool。

## 复现正式候选与替换库

输出目录必须尚不存在。在材料目录执行：

```sh
python3 relink.py --toolchain-bin "$TCBIN" --python "$PWD/.venv/bin/python" --output "$PWD/../relinked-baseline"
```

基线重链必须同时逐字节匹配规范化ELF和BIN参考SHA；日志、命令与result.json保留在输出目录。输入顺序、重复归档、whole-archive、强制符号、specs及链接脚本依赖均来自本次实际链接，不能自行精简掉仍需的对象。

在工作副本编辑 `sources/epdiy/`，保持应用使用的ABI兼容，再执行：

```sh
python3 relink.py --toolchain-bin "$TCBIN" --python "$PWD/.venv/bin/python" --output "$PWD/../relinked-library" --rebuild-epdiy
```

只重编列出的14个epdiy编译单元、替换其归档后重链，不重编私有应用。没有修改库时应原字节匹配；修改后的摘要通常不同，工具如实记录，并仍检查2.1.1/stable渠道记录。库源和必要SDK头文件允许编辑；其他原材料摘要继续校验。

此stable配置裁掉独立HTML/PDF、Lua/轻应用、开发实验与GC动画，保留EPUB内部XHTML、公共解码/字体、正常阅读、水波纹与必要恢复。镜像偏移288的32字节渠道记录必须是PAPERCH、schema1、size32、stable=2、capabilities0x10000、layoutABI1、保留位0。

## 安装边界与许可

工具只生成本地文件，不连接或写入设备。修改库后的启动、显示光学、硬件时序、功耗及栈高水位未验证。目标仍要求匹配Read Pico ESP32-S3/16MB/Zbit与120MHz运行期配置；镜像头80m是原生成参数，不能据此改变产品运行时序。

安装沿用匹配2.1.1完整固件包的真实分区/bootloader/OTA/备份说明；应用地址以随附flasher_args为准。不得在未知活动槽时机械覆盖0x10000，不把OTA初始化当日常升级步骤，也不把其他版本bootloader混入完整安装。已知旧底座是否兼容须由维护者精确登记，不能据IDF字符串相同推断。

`APPLICATION-RELINK-PERMISSION.txt` 说明替换库后重组合、重链、安装及调试修改所需逆向的权利；第三方许可证与NOTICE继续适用。许可源与范围见 `LICENSES/`、`NOTICE.zh.txt` 和 `license-provenance.json`。材料不保证编译实现不可被检查。

本ZIP使用标准ZIP LZMA方法14压缩；可用 `python3 -m zipfile -e 资料包.zip relink-materials` 解压，旧版unzip可能不支持该方法。
