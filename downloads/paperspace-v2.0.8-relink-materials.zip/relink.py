#!/usr/bin/env python3
"""Rebuild supplied LGPL library objects and relink supplied application objects locally."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import shutil


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--emsdk', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--only-object', help='rebuild one supplied LGPL object; others remain as supplied')
    p.add_argument('--link-only', action='store_true')
    a = p.parse_args()
    packet, sdk, output = Path(__file__).resolve().parent, a.emsdk.expanduser().resolve(), a.output.absolute()
    output.mkdir(parents=True, exist_ok=True)
    plan = json.loads((packet / 'relink-plan.json').read_text())
    revision = sdk / 'upstream/emscripten/emscripten-revision.txt'
    if not revision.is_file() or revision.read_text().strip() != plan['emscripten_revision']:
        p.error('exact Emscripten 4.0.17 revision required; use the official SDK instructions')
    env = dict(os.environ, EM_CONFIG=str(sdk / '.emscripten'))
    replacements = {'@PACKET@': str(packet), '@SOURCE@': str(packet / 'sources'),
                    '@OBJECTS@': str(packet / 'objects'), '@EMSDK@': str(sdk), '@OUTPUT@': str(output)}

    def expand(command):
        result = []
        for token in command:
            for name, value in replacements.items():
                token = token.replace(name, value)
            result.append(token)
        return result

    if a.only_object and a.only_object not in {x['object'] for x in plan['library_compiles']}:
        p.error('only-object must name a supplied LGPL library object')
    if not a.link_only:
        for item in plan['library_compiles']:
            if a.only_object and item['object'] != a.only_object:
                continue
            subprocess.run(expand(item['command']), env=env, check=True)
    subprocess.run(expand(plan['link']), env=env, check=True)
    shutil.copy2(packet / 'browser-entry.html', output / 'index.html')
    shutil.copy2(packet / 'browser-entry.js', output / 'browser-entry.js')
    print('Recombined program: ' + str(output / 'reader.js'))


if __name__ == '__main__':
    main()
