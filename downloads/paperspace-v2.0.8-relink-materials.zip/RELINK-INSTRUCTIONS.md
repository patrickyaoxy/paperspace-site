# 修改 epdiy 库并重链接浏览器程序

本材料绑定 v2.0.8 / 79f2f5ad303b9a588d551e3e0eb4b6e5735bc56b 的浏览器候选，提供修改版 LGPL 库源、实际编译依赖、必要 host 适配与生成器、280 个应用/库可重链接对象、胶水和演示输入。不是整个应用源码。完整许可见 LICENSES/、NOTICE.txt、COPYRIGHT-NOTICES.txt 和 APPLICATION-RELINK-PERMISSION.txt。逐文件 SHA-256 见 materials-manifest.json。

1. 从官方 https://github.com/emscripten-core/emsdk 安装 Emscripten 4.0.17。SDK 仓库固定提交 d7b4130688bfa348392b921ab04015aa15c4f154；Emscripten revision 必须为 bb11bae9af3a6551132655a0908f86889d2d423b。按官方工具链说明安装和激活，可能需要网络取得 SDK 与 zlib 1.3.1 port。
2. 先复制一份解压材料作为工作副本；脚本会重写该副本的库对象。编辑 sources/firmware/read_pico_firmware/components/epdiy/，或相关 port/ 库适配。实际编译源与参数见 relink-plan.json 的 library_compiles。port/out/ 是随附生成结果；只改生成结果可直接重编，改原输入或生成器需相应重新生成。
3. 执行 `python3 relink.py --emsdk /自己的/emsdk --output /新的/输出目录`。它使用提供的实际编译参数重编库，再和应用对象重新链接。`--only-object c-0.o` 可只重编一个明确列出的库对象；`--link-only` 复用所有对象直接链接。输出目录应为新的独占目录。
4. 执行 `python3 serve.py --directory /新的/输出目录 --port 4188`，在支持 SharedArrayBuffer 的现代浏览器打开 `http://127.0.0.1:4188/`。服务提供 COOP/COEP；直接打开 file:// 不支持 pthread 运行。
5. 操作首页、打开设置、返回主页，验证修改版库的实际运行。工具链/参数匹配和链接成功不等于产品功能验收；任意库修改仍需相应验证。

这些操作只处理演示数据，不需要私有仓库、用户设备或刷机。对象含原编译调试信息，可能暴露符号与路径；脚本不依赖那些原 checkout 路径存在。供修改库重组合应用的权利及必要逆向不受限制，第三方各自许可证继续适用。本材料不声称 Windows、Safari、真实设备或任何库修改均已验证。

公开构建去除了对象与 WASM 的 DWARF 调试段，保留必要链接符号和重定位。重新链接后可使用匹配官方 SDK 的 upstream/bin/llvm-strip --strip-debug reader.wasm 去除调试段；这不改变系统行为。运行断言的文件名、接口和链接符号仍可能可见，不作实现不可检查的保证。
