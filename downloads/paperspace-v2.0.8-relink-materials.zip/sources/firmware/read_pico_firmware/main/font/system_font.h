/* 独立 UI 字体接口。/ Independent UI font interface. SPDX-License-Identifier: Apache-2.0 */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
esp_err_t system_font_init(void);
/// 独立系统字体：0空山楷、1得意黑、2内置救援，3自选路径。/ Independent UI font selection.
esp_err_t system_font_select(uint8_t choice);
uint8_t system_font_choice(void);
/// 卡上任意合法TTF；成功才保存路径/长度，不计算全文摘要，失败保实际旧源。/ Any valid SD TTF; persist selection only on success, preserve the actual old source on failure.
esp_err_t system_font_apply_path(const char* path,bool* storage_failed);
/// 实际活动源，借用指针；字体操作线程使用，下一次变更前复制。/ Borrowed active source; font-management caller copies before a change.
const char* system_font_path(void);
/// 当前UI字体源/界面倍率代际，启动内循环计数；不证明覆盖。/ Current UI source/scale generation, wrapping within one boot; not coverage proof.
uint32_t system_font_generation(void);
/// 切换并保存，任一步失败恢复实际旧资源（含兼容默认路径）。/ Apply/store with source-aware rollback.
esp_err_t system_font_apply(uint8_t choice,bool* storage_failed);
/// 启动直接装载所选字体必要结构；不全文SHA，失败保留选择并使用救援。/ Load the selected source directly; no full-file hash, rescue on failure.
esp_err_t system_font_boot_begin(void);
typedef enum { SYSTEM_FONT_JOB_IDLE, SYSTEM_FONT_JOB_PENDING, SYSTEM_FONT_JOB_APPLIED, SYSTEM_FONT_JOB_FAILED } system_font_job_status_t;
/// 排队切换，下一step结构加载与保存一次提交；失败保旧，提交前取消不换字体。/ Queue one atomic structural load/store; failure or pre-commit cancellation retains the old source.
esp_err_t system_font_apply_path_begin(const char* path);
esp_err_t system_font_apply_begin(uint8_t choice);
/// 一次完成有界TTF结构加载与事务提交，无全文读取阶段。/ Complete bounded TTF structure loading and storage without a full-file pass.
system_font_job_status_t system_font_change_step(void);
void system_font_change_cancel(void);
/// 兼容接口：不再有后台SHA确认中的可见临时源，恒为false。/ Compatibility query; no provisional background-hash source remains.
bool system_font_change_visible(void);
typedef struct {
    uint64_t probe_us,structure_us,hash_us,hash_bytes; ///< 阶段耗时；hash_us/hash_bytes恒零 / Phase times; hash fields remain zero
} system_font_change_metrics_t;
/// 读取当前请求阶段耗时；页面准备/呈现由调用者单独记录。/ Read request timing; the caller measures page preparation/presentation separately.
bool system_font_change_metrics(system_font_change_metrics_t* metrics);
/// 换卡/USB/文件写入前撤销候选和活动卡字体，保留持久设置；busy时调用者不能开始写卡。/ Revoke card sources before mutation; retain settings and require success before card writes.
esp_err_t system_font_source_invalidate(void);
system_font_job_status_t system_font_change_status(esp_err_t* error,bool* storage_failed,uint64_t* done,uint64_t* total);
/// 基础UI字号只换算一次，四舍五入并限12..120；底层测量/准备/绘制仍接收实际px。/ Scale base UI size once, round and clamp12..120; measure/prepare/draw still take physical px.
int system_font_ui_px(int base_px);
int system_font_width(int px,const char* text);
/// 只查当前字库cmap，不栅格化或分配字形；内存不足不能冒充缺字。/ Query current cmap without raster allocation; OOM is not a missing glyph.
bool system_font_has_glyph(uint32_t codepoint);
/// 按字号字框/基线采样覆盖率，保留字形留白；已定义空格返回全零，缺字绘可辨占位并由status保留MISSING；未就绪失败。
/// Sample user/rescue glyphs or a recognizable missing placeholder; status APIs retain missing coverage.
bool system_font_sample_glyph(uint32_t codepoint,int px,uint8_t columns,
                              uint8_t rows,uint8_t* coverage);
typedef enum {
    SYSTEM_FONT_GLYPH_AVAILABLE, ///< 采样成功 / Sampled
    SYSTEM_FONT_GLYPH_MISSING, ///< 当前字库未定义 / Absent from current font
    SYSTEM_FONT_GLYPH_UNAVAILABLE, ///< 未就绪或采样失败 / Not ready or sampling failed
} system_font_glyph_status_t;
/// 只查常驻cmap，不采样/分配/读文件；未就绪或owner busy返回UNAVAILABLE。
system_font_glyph_status_t system_font_glyph_coverage_status(uint32_t codepoint);
/// 区分当前字库缺字与采样资源暂不可用；不切换字体。/ Distinguish missing coverage from unavailable sampling without switching fonts.
system_font_glyph_status_t system_font_sample_glyph_status(uint32_t codepoint,int px,
    uint8_t columns,uint8_t rows,uint8_t* coverage);
typedef enum {
    SYSTEM_FONT_DIAG_OK, SYSTEM_FONT_DIAG_NOT_READY, SYSTEM_FONT_DIAG_INVALID,
    SYSTEM_FONT_DIAG_COVERAGE_MISSING, SYSTEM_FONT_DIAG_GLYPH_IO,
    SYSTEM_FONT_DIAG_GLYPH_ARENA, SYSTEM_FONT_DIAG_COMPOSITE,
    SYSTEM_FONT_DIAG_ENTRY_ALLOC, SYSTEM_FONT_DIAG_BITMAP_ALLOC,
    SYSTEM_FONT_DIAG_EMPTY_METRICS, SYSTEM_FONT_DIAG_BITMAP_MISSING,
    SYSTEM_FONT_DIAG_CACHE_GENERATION,
    SYSTEM_FONT_DIAG_OWNER_BUSY, ///< 当前调用不能获取字体所有权 / Ownership unavailable to this call
    SYSTEM_FONT_DIAG_RASTER_ALLOC, ///< 栅格临时分配失败 / Raster temporary allocation failed
} system_font_diag_error_t;
typedef struct system_font_glyph_diagnostic {
    uint32_t font_generation,cache_generation,cache_font_generation;
    unsigned font_id,source; ///< 0未就绪、1当前系统、2内置救援、3占位；font_id兼容选项 / Numeric source and fixed font option
    int coverage; ///< -1未查、0缺失、1存在 / Unqueried, absent, present
    bool sampled,cache_hit;
    system_font_diag_error_t error;
} system_font_glyph_diagnostic_t;
/// 同一次真实采样的原因与缓存代际，无额外重采样/字体回退。/ Diagnose the same sample without resampling or fallback.
system_font_glyph_status_t system_font_sample_glyph_diagnostic(uint32_t codepoint,int px,
    uint8_t columns,uint8_t rows,uint8_t* coverage,system_font_glyph_diagnostic_t* diagnostic);
void system_font_label(uint8_t* fb,int x,int center_y,int px,const char* text,bool center);
/// Draw with explicit 4-bit foreground/background tones for reversed panels.
void system_font_label_tone(uint8_t* fb,int x,int center_y,int px,const char* text,
                            bool center,uint8_t foreground,uint8_t background);

/// 完整普通字覆盖率访问器，坐标以本行顶部为原点；不使用点阵32格采样器。
/// Full ordinary-glyph coverage visitor, relative to line top; independent of the 32-cell dot sampler.
typedef void (*system_font_coverage_visit_t)(void* context,int x,int y,uint8_t coverage);
bool system_font_visit_label(int px,const char* text,system_font_coverage_visit_t visitor,void* context);
/// 事件阶段准备普通字形；缺字使用无缓存占位并返回true/诊断MISSING，其他失败返回false；visitor只读。/ Event-stage glyph preparation; visitor reads prepared glyphs only.
bool system_font_prepare_label(int px,const char* text);

/// 单主页准备集合：释放旧pin，保留额度最多224KiB，仍在既有256KiB内。
bool system_font_prepare_begin(void);
size_t system_font_prepared_bytes(void);

/// 只读缓存宽度；缺字计一个px占位，已有字形未准备返回INT_MAX；不做SD/栅格化。
int system_font_width_prepared(int px,const char* text);

typedef enum {SYSTEM_FONT_PREPARE_OK,SYSTEM_FONT_PREPARE_MISSING,SYSTEM_FONT_PREPARE_MEMORY,SYSTEM_FONT_PREPARE_UNAVAILABLE,SYSTEM_FONT_PREPARE_BUSY,SYSTEM_FONT_PREPARE_INVALID,SYSTEM_FONT_PREPARE_IO}system_font_prepare_error_t;
system_font_prepare_error_t system_font_prepare_error(void);

/// 本轮准备曾以占位符显示缺字；不表示IO/OOM成功。
bool system_font_prepared_has_missing(void);
