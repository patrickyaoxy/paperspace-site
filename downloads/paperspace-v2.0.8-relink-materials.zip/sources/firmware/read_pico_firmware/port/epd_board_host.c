/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * host 版板级定义，替代官方的 components/read_pico/read_pico_board.c。
 *
 * 官方的板级文件要通过 I2C 和 FCA9555 扩展脚去开 SY7636A 的电源轨、读 PGOOD、
 * 复位触摸，并绑定 LCD 总线引脚。模拟器里这些都不存在，所以这里只实现 epdiy
 * 要求的板级钩子：控制脚状态记账、电源轨记账、温度返回定值。真机适配（684 画布、
 * PMU VCOM、触摸坐标）在 B4 阶段接入，不在这里假装。
 *
 * Host board definition replacing read_pico_board.c. The real one drives I2C rails
 * and expander pins; here only epdiy's board hooks exist, with control-pin and rail
 * bookkeeping plus a fixed temperature. Real-device concerns arrive in a later stage.
 *
 * 冻结：不写 SY7636A 的 VCOM / VLDO / 放电 / 延时 / VCOMCTL。
 * Frozen: never write SY7636A VCOM / VLDO / discharge / delay / VCOMCTL.
 */

#include "epd_board.h"
#include "epdiy.h"
#include "host_native.h"
#include "read_pico_epd_timing.h"

#include <esp_err.h>
#include <esp_log.h>
#include <stdbool.h>
#include <stdint.h>

static const char* TAG = "board_host";

static epd_ctrl_state_t s_ctrl = { 0 };
static bool s_power_on;
static int s_vcom_mv = 1290;
static int s_vcomctl_pulses;
static int s_power_cycles;

// host 上总线引脚没有意义，但 epd_lcd.h 的配置结构要求填满。
static lcd_bus_config_t s_lcd_bus = {
    .data = {
        GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC,
        GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC,
        GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC,
        GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC, GPIO_NUM_NC,
    },
    .clock = GPIO_NUM_NC,
    .ckv = GPIO_NUM_NC,
    .start_pulse = GPIO_NUM_NC,
    .leh = GPIO_NUM_NC,
    .stv = GPIO_NUM_NC,
};

static void board_init(uint32_t epd_row_width) {
    ESP_LOGI(TAG, "host board init, row width %u", (unsigned)epd_row_width);

    // 真机上 LCD 外设由板级装配：按总线把行时序解出来再交给 epdiy。
    // host 复用官方求解器 read_pico_epd_timing.c，时序数字与真机一致。
    const EpdDisplay_t* display = epd_get_display();
    if (display != NULL) {
        const int init_pclk_mhz = display->bus_speed * 8 / display->bus_width;
        read_pico_epd_scan_t scan;
        read_pico_epd_scan(init_pclk_mhz, READ_PICO_EPD_SCAN_FULL, &scan);
        read_pico_epd_init_lcd(
            &s_lcd_bus, display->bus_width, display->width, display->height, &scan
        );
    }
    s_ctrl.ep_latch_enable = false;
    s_ctrl.ep_output_enable = false;
    s_ctrl.ep_sth = false;
    s_ctrl.ep_mode = false;
    s_ctrl.ep_stv = false;
}

static void board_deinit(void) {
    s_power_on = false;
}

static void board_set_ctrl(epd_ctrl_state_t* state, const epd_ctrl_state_t* const target) {
    *state = *target;
}

static void board_poweron(epd_ctrl_state_t* state) {
    // 真机走 SY7636A 时序：EN 拉高 → VCOM/VLDO/DELAY → OPERATION=ON → 轮询 PGOOD。
    // 模拟器只记账，电源轨标志给板级状态页用。
    s_power_on = true;
    s_power_cycles += 1;
    state->ep_output_enable = true;
    // 同步给板级状态页与 SY7636A 假缓存（PGOOD 恒高，见 port/host_power.c）。
    // / Sync the status page and fake SY7636A cache (PGOOD always high in host_power.c).
    host_board_note_rails(true);
}

static void board_measure_vcom(epd_ctrl_state_t* state) {
    (void)state;
    // 真机通过外部 ADC 测反冲；模拟器没有这个观测能力。
}

static void board_poweroff(epd_ctrl_state_t* state) {
    s_power_on = false;
    state->ep_output_enable = false;
    host_board_note_rails(false);
}

static void board_set_vcom(int vcom) {
    // VCOM 属于面板高压，记录只为把值透给状态页与 PLFB001 元数据。
    s_vcom_mv = vcom;
}

static float board_get_temperature(void) {
    // 官方波形只有 0–50°C 一个温度档，display.c 固定传 25。
    return 25.0f;
}

static esp_err_t board_gpio_set_direction(int pin, bool make_input) {
    (void)pin;
    (void)make_input;
    return ESP_ERR_NOT_SUPPORTED;
}

static bool board_gpio_read(int pin) {
    (void)pin;
    return false;
}

static esp_err_t board_gpio_write(int pin, bool value) {
    (void)pin;
    (void)value;
    return ESP_ERR_NOT_SUPPORTED;
}

const EpdBoardDefinition epd_board_read_pico_host = {
    .init = board_init,
    .deinit = board_deinit,
    .set_ctrl = board_set_ctrl,
    .poweron = board_poweron,
    .measure_vcom = board_measure_vcom,
    .poweroff = board_poweroff,
    .set_vcom = board_set_vcom,
    .get_temperature = board_get_temperature,
    .gpio_set_direction = board_gpio_set_direction,
    .gpio_read = board_gpio_read,
    .gpio_write = board_gpio_write,
};

/* ---- 给 host 上层用的小接口 / Host-side helpers ---- */

bool host_board_power_on(void) { return s_power_on; }
int host_board_vcom_mv(void) { return s_vcom_mv; }
int host_board_power_cycles(void) { return s_power_cycles; }
int host_board_vcomctl_pulses(void) { return s_vcomctl_pulses; }
