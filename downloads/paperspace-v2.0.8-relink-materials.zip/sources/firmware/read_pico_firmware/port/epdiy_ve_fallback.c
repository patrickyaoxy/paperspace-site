/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * 三个 xtensa 向量加速函数的 C 等价实现，供 host 目标使用。
 *
 * 官方把这三个函数放在汇编里（components/epdiy/src/output_common/lut.S 与
 * src/diff.S），因为 ESP32-S3 的向量单元能把 16 字节一次算完。C 版在官方树里
 * 只有「非 S3」路径，而本 fork 用 CONFIG_IDF_TARGET_ESP32S3 关掉了那些分支，
 * 所以 host 上必须自己补。这里逐行照抄官方 C 参考实现的语义，不引入新算法。
 *
 * C equivalents of the three xtensa vector-accelerated helpers. The official tree
 * implements them in assembly (lut.S and diff.S) and only keeps C fallbacks for
 * non-S3 targets, which this fork compiles out. These are line-by-line ports of
 * the official C reference semantics, no new algorithms.
 *
 * 冻结：只补汇编等价物，不改 epdiy 的算法与数据布局。
 * Frozen: assembly equivalents only; no algorithm or layout changes.
 */

#include "epdiy.h"

#include <stdint.h>
#include <string.h>

/* ---- lut.S: calc_epd_input_1ppB_1k_S3_VE_aligned ---- */

// 与 output_common/lut.c:144-155 的 lookup_pixels_in_VE_LUT 完全相同：1K 填充
// LUT 每项占 32 位，一次查 4 个像素并拼成一个字节。
static inline uint8_t host_lookup_pixels_in_VE_LUT(uint32_t in, const uint8_t* conversion_lut) {
    const uint32_t* padded_lut = (const uint32_t*)conversion_lut;
    uint8_t out = (uint8_t)(padded_lut[(in >> 24) & 0xFF] << 6);
    out |= (uint8_t)(padded_lut[(in >> 16) & 0xFF] << 4);
    out |= (uint8_t)(padded_lut[(in >> 8) & 0xFF] << 2);
    out |= (uint8_t)(padded_lut[(in >> 0) & 0xFF]);
    return out;
}

/// 对齐段查表：入参长度按官方约定以「像素」计，每 4 个像素出一个字节。
void calc_epd_input_1ppB_1k_S3_VE_aligned(
    const uint32_t* ld, uint8_t* epd_input, const uint8_t* conversion_lut, uint32_t epd_width
) {
    const uint32_t groups = epd_width / 4;
    for (uint32_t i = 0; i < groups; i++) {
        epd_input[i] = host_lookup_pixels_in_VE_LUT(ld[i], conversion_lut);
    }
}

/* ---- diff.S: epd_apply_line_mask_VE ---- */

/// 把行缓冲按 16 字节块与掩码逐字节与。官方汇编只处理整 16 字节块
/// （循环次数 = mask_len >> 4），这里保持一致；mask_len 为 304 时正好整除。
void epd_apply_line_mask_VE(uint8_t* line, const uint8_t* mask, int mask_len) {
    const int blocks = mask_len >> 4;
    for (int b = 0; b < blocks; b++) {
        const int base = b * 16;
        for (int i = 0; i < 16; i++) {
            line[base + i] = (uint8_t)(line[base + i] & mask[base + i]);
        }
    }
}

/* ---- diff.S: epd_interlace_4bpp_line_VE ---- */

/// 逐行交织 to/from 的高低位半字节，并记录列脏位。语义与 render.c:464-479 的
/// _interlace_line_unaligned 相同；len 按像素计，返回 1 表示有差异。
uint32_t epd_interlace_4bpp_line_VE(
    const uint8_t* to, const uint8_t* from, uint8_t* interlaced, uint8_t* col_dirtyness, int fb_width
) {
    int dirty = 0;
    for (int x = 0; x < fb_width; x++) {
        uint8_t t = *(to + x / 2);
        uint8_t f = *(from + x / 2);
        t = (x % 2) ? (uint8_t)(t >> 4) : (uint8_t)(t & 0x0F);
        f = (x % 2) ? (uint8_t)(f >> 4) : (uint8_t)(f & 0x0F);
        col_dirtyness[x / 2] = (uint8_t)(col_dirtyness[x / 2] | ((t ^ f) << (4 * (x % 2))));
        dirty |= (t ^ f);
        interlaced[x] = (uint8_t)((t << 4) | f);
    }
    return (uint32_t)(dirty ? 1 : 0);
}
