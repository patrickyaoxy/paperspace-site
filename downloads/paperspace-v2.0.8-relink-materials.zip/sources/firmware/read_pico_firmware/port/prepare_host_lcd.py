#!/usr/bin/env python3
"""只为 native 生成原子行 owner 发布的适配副本，不修改设备源码。
Generate native-only atomic owner publication copies; keep device sources intact.
"""
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'components/epdiy/src'


def adapt(relative, before, after, target):
    path = SOURCE / relative
    text = path.read_text()
    if text.count(before) != 1:
        raise RuntimeError(f'官方源码契约变化，停止生成适配副本：{relative}')
    text = text.replace(before, after)
    # 副本在 out 内，保留原文件的相对头文件解析。/ Preserve original relative header resolution.
    def include(match):
        header = (path.parent / match[1]).resolve()
        return f'#include "{header}"' if header.is_file() else match[0]
    text = re.sub(r'#include "([^"]+)"', include, text)
    target.write_text(f'#line 1 "{path}"\n' + text)


if __name__ == '__main__':
    out = HERE / 'out'
    out.mkdir(exist_ok=True)
    adapt('output_lcd/render_lcd.c', 'ctx->line_threads[l] = thread_id;',
          '__atomic_store_n(&ctx->line_threads[l], (uint8_t)thread_id, __ATOMIC_RELEASE);',
          out / 'render_lcd_host.c')
    adapt('output_common/render_context.c', 'ctx->line_threads[i] = i % NUM_RENDER_THREADS;',
          '__atomic_store_n(&ctx->line_threads[i], UINT8_MAX, __ATOMIC_RELEASE);',
          out / 'render_context_host.c')
