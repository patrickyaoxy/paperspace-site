// GPIO 垫片：host 上无引脚，全部返回安全值。
#pragma once
#include "esp_err.h"
#include <stdint.h>
typedef int gpio_num_t;
#define GPIO_NUM_NC ((gpio_num_t)-1)
#define GPIO_NUM_0 ((gpio_num_t)0)
#define GPIO_NUM_1 ((gpio_num_t)1)
#define GPIO_MODE_DISABLE 0
#define GPIO_MODE_INPUT 1
#define GPIO_MODE_OUTPUT 2
#define GPIO_MODE_INPUT_OUTPUT 3
#define GPIO_PULLUP_DISABLE 0
#define GPIO_PULLUP_ENABLE 1
#define GPIO_PULLDOWN_DISABLE 0
#define GPIO_PULLDOWN_ENABLE 1
#define GPIO_INTR_DISABLE 0
#define GPIO_INTR_POSEDGE 1
#define GPIO_INTR_NEGEDGE 2
#define GPIO_INTR_ANYEDGE 3
#define GPIO_INTR_LOW_LEVEL 4
#define GPIO_INTR_HIGH_LEVEL 5
#define GPIO_IS_VALID_GPIO(x) ((x) >= 0)
typedef struct {
    uint64_t pin_bit_mask;
    int mode;
    int pull_up_en;
    int pull_down_en;
    int intr_type;
} gpio_config_t;
static inline esp_err_t gpio_config(const gpio_config_t* c) { (void)c; return ESP_OK; }
static inline esp_err_t gpio_reset_pin(gpio_num_t p) { (void)p; return ESP_OK; }
static inline esp_err_t gpio_set_direction(gpio_num_t p, int m) { (void)p; (void)m; return ESP_OK; }
static inline esp_err_t gpio_set_level(gpio_num_t p, int l) { (void)p; (void)l; return ESP_OK; }
static inline int gpio_get_level(gpio_num_t p) { (void)p; return 1; }
static inline esp_err_t gpio_set_pull_mode(gpio_num_t p, int m) { (void)p; (void)m; return ESP_OK; }
static inline esp_err_t gpio_wakeup_enable(gpio_num_t p, int t) { (void)p; (void)t; return ESP_OK; }
static inline esp_err_t gpio_wakeup_disable(gpio_num_t p) { (void)p; return ESP_OK; }
static inline esp_err_t gpio_isr_handler_add(gpio_num_t p, void (*fn)(void*), void* a) { (void)p; (void)fn; (void)a; return ESP_OK; }
static inline esp_err_t gpio_isr_handler_remove(gpio_num_t p) { (void)p; return ESP_OK; }
static inline esp_err_t gpio_install_isr_service(int f) { (void)f; return ESP_OK; }
