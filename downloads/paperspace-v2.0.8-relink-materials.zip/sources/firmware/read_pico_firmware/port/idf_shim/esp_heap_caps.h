#pragma once
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "../host_heap.h"
#define MALLOC_CAP_8BIT (1 << 2)
#define MALLOC_CAP_DMA (1 << 3)
#define MALLOC_CAP_SPIRAM (1 << 10)
#define MALLOC_CAP_INTERNAL (1 << 11)
#define MALLOC_CAP_DEFAULT (1 << 12)
#define MALLOC_CAP_32BIT (1 << 1)
static inline void* heap_caps_malloc(size_t n, int caps) { return host_heap_alloc(n, caps); }
static inline void* heap_caps_calloc(size_t n, size_t s, int caps) { return host_heap_calloc(n, s, caps); }
static inline void* heap_caps_realloc(void* p, size_t n, int caps) { return host_heap_realloc(p, n, caps); }
static inline void heap_caps_free(void* p) { host_heap_free(p); }
static inline void* heap_caps_aligned_alloc(size_t align, size_t n, int caps) {
    return host_heap_aligned_alloc(align, n, caps);
}
static inline void* heap_caps_aligned_calloc(size_t align, size_t n, size_t s, int caps) {
    return host_heap_aligned_calloc(align, n, s, caps);
}
static inline void heap_caps_aligned_free(void* p) { host_heap_free(p); }
static inline size_t heap_caps_get_free_size(int caps) { (void)caps; return (size_t)64 * 1024 * 1024; }
static inline size_t heap_caps_get_largest_free_block(int caps) { (void)caps; return (size_t)32 * 1024 * 1024; }
static inline size_t heap_caps_get_total_size(int caps) { (void)caps; return (size_t)64 * 1024 * 1024; }
