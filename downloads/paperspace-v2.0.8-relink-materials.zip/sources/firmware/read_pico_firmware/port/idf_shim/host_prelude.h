// host 预包含头：官方代码依赖 IDF 头间接带入的 libc 头（assert/stdlib/string），
// 在 host 上补齐，避免为每个文件单独打补丁。
// Forced-include prelude: the official tree relies on IDF headers pulling in libc
// (assert/stdlib/string) transitively; supply them here instead of patching files.
#pragma once
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
