// 日志垫片：直接打到 stdout/stderr。/ Log shim: straight to stdout/stderr.
#pragma once
#include <stdio.h>
#include <stdlib.h>
// 官方 read_pico_init.c:42 会按组件名调低日志级别；host 上没有分级过滤，
// 只把这句吃掉。PAPERLAB_VERBOSE 打开时打印出来说明它被调用过。
// The official read_pico_init.c:42 lowers a component's log level; the host has no
// severity filter, so this is swallowed (logged when PAPERLAB_VERBOSE is set).
static inline void esp_log_level_set(const char* tag, int level) {
    (void)tag; (void)level;
}
#define ESP_LOG_NONE 0
#define ESP_LOG_ERROR 1
#define ESP_LOG_WARN 2
#define ESP_LOG_INFO 3
#define ESP_LOG_DEBUG 4
#define ESP_LOG_VERBOSE 5
#define ESP_LOGE(tag, fmt, ...) fprintf(stderr, "E %s: " fmt "\n", tag, ##__VA_ARGS__)
#define ESP_LOGW(tag, fmt, ...) fprintf(stderr, "W %s: " fmt "\n", tag, ##__VA_ARGS__)
#define ESP_LOGI(tag, fmt, ...) fprintf(stdout, "I %s: " fmt "\n", tag, ##__VA_ARGS__)
#define ESP_LOGD(tag, fmt, ...) do { } while (0)
#define ESP_LOGV(tag, fmt, ...) do { } while (0)
#define ESP_LOG_LEVEL_LOCAL(l, tag, fmt, ...) do { } while (0)
