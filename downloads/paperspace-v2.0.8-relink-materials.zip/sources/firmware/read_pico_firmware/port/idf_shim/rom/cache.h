// rom/cache.h 垫片：host 上预取是空操作。
#pragma once
#include <stdint.h>
static inline void Cache_Start_DCache_Preload(uint32_t addr, uint32_t size, uint32_t dir) {
    (void)addr; (void)size; (void)dir;
}
static inline void Cache_Read_Enable(int cpu, int autoload) { (void)cpu; (void)autoload; }
static inline void Cache_Read_Disable(int cpu) { (void)cpu; }
