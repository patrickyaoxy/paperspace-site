// xtensa 内建垫片：host 上只求能编过、计数返回 0。
#pragma once
#include <stdint.h>
#define XTHAL_GET_CCOUNT() 0u
#define XTHAL_GET_CCOMPARE(n) 0u
#define XTHAL_SET_CCOMPARE(n, v) do { } while (0)
static inline uint32_t xthal_get_ccount(void) { return 0u; }
