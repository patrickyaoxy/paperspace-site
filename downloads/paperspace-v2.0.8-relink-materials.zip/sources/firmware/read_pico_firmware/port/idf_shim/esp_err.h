// 官方固件的 ESP-IDF 垫片：错误码。/ ESP-IDF shim for the official firmware: error codes.
#pragma once
#include <stdio.h>
#include <stdint.h>
typedef int esp_err_t;
#define ESP_OK 0
#define ESP_FAIL -1
#define ESP_ERR_NO_MEM 0x101
#define ESP_ERR_INVALID_ARG 0x102
#define ESP_ERR_INVALID_STATE 0x103
#define ESP_ERR_INVALID_SIZE 0x104
#define ESP_ERR_NOT_FOUND 0x105
#define ESP_ERR_NOT_SUPPORTED 0x106
#define ESP_ERR_TIMEOUT 0x107
#define ESP_ERR_NOT_FINISHED 0x108
#define ESP_ERR_INVALID_RESPONSE 0x109
#define ESP_ERR_NVS_NO_FREE_PAGES 0x1101
#define ESP_ERR_NVS_NEW_VERSION_FOUND 0x1102
#define ESP_ERROR_CHECK(x) do { esp_err_t r_ = (x); if (r_ != ESP_OK) { \
    fprintf(stderr, "ESP_ERROR_CHECK(%s) failed: 0x%x\n", #x, (unsigned)r_); } } while (0)
static inline const char* esp_err_to_name(esp_err_t e) {
    switch (e) {
        case ESP_OK: return "ESP_OK";
        case ESP_FAIL: return "ESP_FAIL";
        case ESP_ERR_NO_MEM: return "ESP_ERR_NO_MEM";
        case ESP_ERR_INVALID_ARG: return "ESP_ERR_INVALID_ARG";
        case ESP_ERR_INVALID_STATE: return "ESP_ERR_INVALID_STATE";
        case ESP_ERR_NOT_FOUND: return "ESP_ERR_NOT_FOUND";
        case ESP_ERR_TIMEOUT: return "ESP_ERR_TIMEOUT";
        case ESP_ERR_NOT_FINISHED: return "ESP_ERR_NOT_FINISHED";
        default: return "ESP_ERR_?";
    }
}
