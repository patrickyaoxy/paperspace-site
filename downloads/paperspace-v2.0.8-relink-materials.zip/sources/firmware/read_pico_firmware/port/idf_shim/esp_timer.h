#pragma once
#include <stdint.h>
#include <time.h>
// 单调时钟，微秒。/ Monotonic microseconds.
static inline int64_t esp_timer_get_time(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
}
