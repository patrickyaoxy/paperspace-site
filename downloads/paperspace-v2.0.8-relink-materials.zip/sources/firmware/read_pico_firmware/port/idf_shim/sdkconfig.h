// 面板/板级相关的定值。数值取自真机 sdkconfig，保证时序求解与引脚宏在 host 上
// 与真机一致（host 上这些引脚没有硬件，只影响打印与记账）。
// Panel/board constants. Values copied from the device sdkconfig so timing solver
// and pin macros match the device; on the host the pins have no hardware and only
// affect logging and bookkeeping.
#pragma once
#define CONFIG_IDF_TARGET "esp32s3"
#define CONFIG_IDF_TARGET_ESP32S3 1
#define CONFIG_SPIRAM 1
#define CONFIG_SPIRAM_MODE_OCT 1
#define CONFIG_EPD_LUT_1K 1
#define CONFIG_FREERTOS_HZ 1000

// 板级 I2C 与中断脚（sdkconfig 真机值）/ Board I2C and interrupt pins (device values).
#define CONFIG_READ_PICO_I2C_PORT 0
#define CONFIG_READ_PICO_I2C_SCL_GPIO 40
#define CONFIG_READ_PICO_I2C_SDA_GPIO 39
#define CONFIG_READ_PICO_I2C_FREQ_HZ 400000
#define CONFIG_READ_PICO_IOE_INT_GPIO 41
#define CONFIG_READ_PICO_TP_INT_GPIO 43

// PSRAM 时钟：display.h:26-30 的说明提到 DMA 余量依赖它，host 上只用于日志。
// PSRAM clock: display.h:26-30 notes DMA slack depends on it; logging only here.
#define CONFIG_SPIRAM_SPEED_120M 1
#define CONFIG_ESP32S3_DATA_CACHE_LINE_SIZE 64

// 日志级别默认值（esp_log.h 垫片不分级，只为编译期引用存在）。
// Default log levels (the esp_log.h shim has no filtering; compile-time only).
#define CONFIG_LOG_DEFAULT_LEVEL 3
#define CONFIG_LOG_MAXIMUM_LEVEL 5
