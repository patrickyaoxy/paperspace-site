#pragma once
#include "freertos/FreeRTOS.h"
typedef struct frt_task_s* TaskHandle_t;
typedef void (*TaskFunction_t)(void*);
BaseType_t xTaskCreate(TaskFunction_t fn, const char* name, uint32_t stack, void* arg, UBaseType_t prio, TaskHandle_t* out);
BaseType_t xTaskCreatePinnedToCore(TaskFunction_t fn, const char* name, uint32_t stack, void* arg, UBaseType_t prio, TaskHandle_t* out, BaseType_t core);
void vTaskDelete(TaskHandle_t h);
typedef enum {eRunning,eReady,eBlocked,eSuspended,eDeleted,eInvalid} eTaskState;
eTaskState eTaskGetState(TaskHandle_t h);
void vTaskSuspend(TaskHandle_t h);
void vTaskDelay(TickType_t ticks);
void vTaskDelayUntil(TickType_t* prev, TickType_t ticks);
TickType_t xTaskGetTickCount(void);
TaskHandle_t xTaskGetCurrentTaskHandle(void);
/// 对应 FreeRTOS 的任务通知：计数 + 唤醒。
uint32_t ulTaskNotifyTake(BaseType_t clear_on_exit, TickType_t timeout);
void xTaskNotifyGive(TaskHandle_t h);
void taskYIELD(void);
