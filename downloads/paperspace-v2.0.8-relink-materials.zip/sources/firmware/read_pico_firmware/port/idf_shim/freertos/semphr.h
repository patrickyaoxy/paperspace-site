#pragma once
#include "freertos/FreeRTOS.h"
typedef struct frt_sem_s* SemaphoreHandle_t;
SemaphoreHandle_t xSemaphoreCreateMutex(void);
SemaphoreHandle_t xSemaphoreCreateBinary(void);
SemaphoreHandle_t xSemaphoreCreateRecursiveMutex(void);
BaseType_t xSemaphoreTake(SemaphoreHandle_t s, TickType_t timeout);
BaseType_t xSemaphoreGive(SemaphoreHandle_t s);
BaseType_t xSemaphoreTakeRecursive(SemaphoreHandle_t s, TickType_t timeout);
BaseType_t xSemaphoreGiveRecursive(SemaphoreHandle_t s);
BaseType_t xSemaphoreGiveFromISR(SemaphoreHandle_t s, BaseType_t* woken);
BaseType_t xSemaphoreTakeFromISR(SemaphoreHandle_t s, BaseType_t* woken);
void vSemaphoreDelete(SemaphoreHandle_t s);
