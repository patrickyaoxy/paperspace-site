// FreeRTOS 垫片（pthread 实现）：类型与常量。
// FreeRTOS shim (pthread-backed): types and constants.
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
typedef uint32_t TickType_t;
typedef int BaseType_t;
typedef unsigned int UBaseType_t;
#define pdTRUE 1
#define pdFALSE 0
#define pdPASS 1
#define pdFAIL 0
#define portMAX_DELAY ((TickType_t)0xffffffffU)
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))
#define configTICK_RATE_HZ 1000
#define configMAX_PRIORITIES 25
#define tskNO_AFFINITY 0x7FFFFFFF
#define portTICK_PERIOD_MS 1
/// 中断里用：host 无需真让出，仅保持语义。
#define portYIELD_FROM_ISR() do { } while (0)
#define portENTER_CRITICAL(mux) do { } while (0)
#define portEXIT_CRITICAL(mux) do { } while (0)
BaseType_t xPortGetCoreID(void);
