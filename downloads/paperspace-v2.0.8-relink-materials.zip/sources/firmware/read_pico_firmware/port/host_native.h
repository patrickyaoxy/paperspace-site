/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * host 侧跨文件的小接口：板级定义句柄、LCD 后端状态、刷屏导出钩子。
 *
 * 只给 port/ 下面的文件用，官方代码不包含它。放一个头里是因为这几组函数都很小，
 * 按实现文件拆成四个头反而难找。
 *
 * Host-side cross-file API: the board definition handle, LCD backend state and the
 * refresh export hook.
 *
 * Only files under port/ include it; no official file does. One header because each
 * group is tiny and four headers would only hide them.
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "epd_board.h"

#ifdef __cplusplus
extern "C" {
#endif

/// host 板级定义（port/epd_board_host.c）。官方那份是 epd_board_read_pico。
/// / Host board definition (port/epd_board_host.c); the official one is epd_board_read_pico.
extern const EpdBoardDefinition epd_board_read_pico_host;

/* ---- 板级记账 / Board bookkeeping ---- */

bool host_board_power_on(void);
int host_board_power_cycles(void);
int host_board_vcom_mv(void);
int host_board_vcomctl_pulses(void);
/// 轨状态变化时由 epd_board_host.c 调，同步给板级状态页与 SY7636A 假缓存。
/// / Called by epd_board_host.c on rail changes to sync the status page and the
/// fake SY7636A cache.
void host_board_note_rails(bool on);

/* ---- LCD 后端 / LCD backend ---- */

int host_lcd_frames_started(void);
int host_lcd_underruns(void);
/// 已经触发过多少次"刷新结束"导出。/ How many end-of-refresh exports have fired.
int host_lcd_exports(void);
int host_lcd_line_clocks(void);
int host_lcd_pixel_clock_mhz(void);
void host_lcd_set_verbose(int on);

/// 把 4bpp framebuffer 指针交给 LCD 后端。导出钩子在每轮刷新结束时用它。
/// / Hand the 4bpp framebuffer to the LCD backend; the export hook uses it at the
/// end of every refresh cycle.
void host_lcd_set_framebuffer(uint8_t* fb);
/// 注册"一轮刷新结束"回调（在 LCD 消费线程里调用，cb 必须快且不再进入 epdiy）。
/// / Register an end-of-refresh callback, invoked on the LCD consumer thread.
/// cb must be fast and must not re-enter epdiy.
void host_lcd_set_export(void (*cb)(uint8_t* fb, void* user), void* user);

/* ---- 帧导出 / Frame export ---- */

/// 登记 framebuffer 并挂上导出钩子（幂等）。路径 PAPERLAB_FRAME_PATH，
/// 默认 .paperlab/frame.bin。
/// / Register the framebuffer and the export hook (idempotent). Path from
/// PAPERLAB_FRAME_PATH, default .paperlab/frame.bin.
void frame_export_init(uint8_t* framebuffer);
/// 已导出的帧数（= 最近一次的 sequence）。
/// / Number of exported frames (= the latest sequence).
uint32_t frame_export_count(void);
/// 手动导出一帧，给 B2 的 ui/splash/selftest 三页用（它们不走官方主循环）。
/// / Export one frame by hand, for the B2 ui/splash/selftest pages that do not
/// run the official loop.
void frame_export_once(uint8_t* framebuffer, uint32_t sequence);

#ifdef __cplusplus
}
#endif
