/*
 * SPDX-FileCopyrightText: 2026 mindreset
 * SPDX-License-Identifier: Apache-2.0
 *
 * 中文：host 侧的 heap_caps_* 记账。固件里所有堆分配都走 heap_caps_malloc/free
 * （字体、阅读器缓冲、epdiy 帧缓冲），所以在垫片层加一层计数就能量出"固件自己拿了多少"。
 *
 * 两个用途：
 *   1. 泄漏回归：翻几百页、换几次字体之后，存活字节数应当回到同一水平（scripts/soak-reader.py）；
 *   2. 事前预算：按 MALLOC_CAP_* 分桶量出"要用多少 PSRAM、多少内部 SRAM" —— 真机是
 *      8 MB PSRAM + 512 KB SRAM，后者才是稀缺资源，上机前就该知道够不够。
 *
 * English: host-side accounting for heap_caps_*. All firmware heap traffic goes through
 * heap_caps_malloc/free (fonts, reader buffers, epdiy framebuffers), so counting in the shim
 * measures what the firmware itself holds. Two uses: a leak regression (hundreds of page turns
 * must return to the same level, see scripts/soak-reader.py) and an ahead-of-hardware budget
 * split by MALLOC_CAP_*, because the board has 8 MB PSRAM but only 512 KB of internal SRAM --
 * the scarce resource is the one worth measuring before the board exists.
 *
 * 冻结：只计数，不改分配语义；只有 host 目标用它。
 * Frozen: accounting only, no allocation semantics changed; host target only.
 */
#ifndef HOST_HEAP_H
#define HOST_HEAP_H

#include <stddef.h>
#include <stdbool.h>

// MALLOC_CAP_* 的位值要和 IDF 一致（垫片里的 esp_heap_caps.h 也定义同一批值，
// 用 #ifndef 保护，谁先到都不冲突）。
// The MALLOC_CAP_* values must match IDF. The shim's esp_heap_caps.h defines the same ones;
// the guards keep either include order working.
#ifndef MALLOC_CAP_SPIRAM
#define MALLOC_CAP_SPIRAM (1 << 10)
#endif
#ifndef MALLOC_CAP_INTERNAL
#define MALLOC_CAP_INTERNAL (1 << 11)
#endif

/// 分桶查询：0 = PSRAM、1 = 内部 SRAM、2 = 未指定；其余值表示"全部合计"。
/// Buckets: 0 = PSRAM, 1 = internal SRAM, 2 = unspecified; any other value means "all".
size_t host_heap_live_bytes(int bucket);
size_t host_heap_peak_bytes(int bucket);

/// 当前存活块数。/ Number of live blocks.
size_t host_heap_blocks(void);

size_t host_heap_overhead_bytes(void);

/// 被模拟上限挡掉的分配次数（PAPERLAB_SPIRAM_LIMIT_MB 生效时才有意义）。
/// Allocations refused by the simulated ceiling (only meaningful with PAPERLAB_SPIRAM_LIMIT_MB).
size_t host_heap_limit_hits(void);
size_t host_heap_live_default(void);
size_t host_heap_live_spiram(void);
size_t host_heap_live_internal(void);
size_t host_heap_peak_spiram(void);
size_t host_heap_peak_internal(void);
/// 隔离native故障注入，不进入设备构建。/ Isolated native fault injection, never part of device builds.
bool host_heap_test_limit(size_t bytes);

void* host_heap_alloc(size_t size, int caps);
void* host_heap_calloc(size_t count, size_t size, int caps);
void* host_heap_realloc(void* ptr, size_t size, int caps);
void host_heap_free(void* ptr);
void* host_heap_aligned_alloc(size_t align, size_t size, int caps);
void* host_heap_aligned_calloc(size_t align, size_t count, size_t size, int caps);

#endif
