/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * host 版 LCD 输出层，替代官方的 components/epdiy/src/output_lcd/lcd_driver.c。
 *
 * 官方那个文件是整个固件里唯一绑死 ESP32-S3 的地方：它直接操作 LCD 外设的
 * lcd_ll_* 寄存器、GDMA 描述符与 RMT 通道。这里保留它对外暴露的全部契约
 * （epd_lcd_init / deinit / set_pixel_clock_MHz / set_line_timing 与两个回调
 * 注册接口），把「DMA 按行取数」换成一条独立线程。
 *
 * 为什么必须是独立线程：官方流程里，喂数任务把差分查完 LUT 填进行队列，并在
 * 预填够若干行时启动帧；主线程随后等 frame_done 与两个 feed_done。如果在这里
 * 同步地把整帧排空，喂数任务会卡在自己的循环里等自己填下一行 —— 死锁。真机上
 * 消费方是 DMA 硬件，所以这里也必须是一个与喂数线程并发的消费者。
 *
 * Host LCD backend replacing the only hardware-bound file in the tree. It keeps
 * the same contract but turns DMA-driven line retrieval into a dedicated thread,
 * because the consumer must run concurrently with epdiy's feeder tasks: draining
 * synchronously inside the feeder self-deadlocks, exactly as the DMA hardware
 * would never block on the feeder.
 *
 * 冻结：不碰真实寄存器，也不假装精确时序；这里只保证画面与流程正确。
 * Frozen: no register access and no pretence of exact timing; frames and control
 * flow are what this file owes.
 */

#include "epd_lcd.h"
#include "host_native.h"
#include "lcd_driver.h"
#include "output_common/render_context.h"

#include <esp_log.h>
#include <esp_timer.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/// 2bpp 输出：每行 1216/4 = 304 字节；留出余量。
#define HOST_LINE_BYTES_MAX 512
/// 等一行数据的上限。这是"多久判定供数不足"的耐心值：host 不是实时系统，喂数线程
/// 会被调度器、别的进程、甚至我们自己这次自旋挤掉，实测出现过 687/688 行等了
/// 20ms 的情况。太短会把正常的调度抖动误判成欠载，而欠载会触发官方的
/// guard_draw_result（display.c:173-185）：降 pclk + 整屏刷白，画面直接被清空。
/// 2000 之后仍等不到才报欠载；它是自旋上限，不是时序承诺。
/// How long to wait for a line. This is the patience before declaring an underrun:
/// the host is not real-time — feeders get preempted by the scheduler, by other
/// processes and by our own spin — and 687/688 lines waiting 20 ms was observed.
/// Too short turns ordinary scheduling jitter into an underrun, and an underrun
/// triggers the official guard_draw_result (display.c:173-185): drop pclk and
/// wipe the screen white, which erases the picture. Only past 2000 is it reported.
#define HOST_LINE_WAIT_MS 2000

// 消费者要求喂数线程**领先多少行**才肯消费。
//
// 原来只要求 `prepared >= y + 2`，等于让消费者紧贴着喂数线程跑：实测到 line 251 时
// prepared=254，只领先 3 行，而"认领"和"把数据填进队列"之间本来就有窗口（喂数线程先
// `atomic_fetch_add` 认领、再写 owner、再填队列）。领先量为 0 时，调度一抖消费者就扑空，
// 官方 retrieve_line_isr 随即在空队列上置 EPD_DRAW_EMPTY_LINE_QUEUE，整帧报废。
// 要求领先 16 行（队列容量 64 的四分之一）等于**规定一个缓冲余量**：消费者永远落后喂数
// 线程至少 16 行，填队列那点窗口就被余量吸收了。健康时这个等待不花时间（喂数线程本来就
// 跑在前面），只有消费者追上来时才真的等它。
//
// How far the feeders must be *ahead* before the consumer takes a line. The old gate was
// `prepared >= y + 2`, i.e. the consumer ran right on the feeders' heels: measured, at line 251
// prepared was 254 -- only 3 lines of lead -- and there is an inherent window between *claiming* a
// line (atomic_fetch_add), setting its owner, and filling the queue. With zero lead any scheduling
// jitter makes the consumer miss, the official retrieve_line_isr sets
// EPD_DRAW_EMPTY_LINE_QUEUE on the empty queue, and the whole frame is lost. Demanding 16 lines of
// lead (a quarter of the 64-slot queue) mandates a buffer: the consumer is always at least 16 lines
// behind, which absorbs that window. When the feeders are healthy this costs nothing; it only
// waits when the consumer has caught up.
#define HOST_LINE_LEAD 16
/// 帧号多久不前进就判定卡死并 dump。/ Stall threshold for an in-flight frame.
#define HOST_STALL_TIMEOUT_MS 5000
// 硬卡死最多恢复几次：host 仿真的行队列偶发卡住时，丢一帧继续跑；连续这么多次还卡就认输。
// How many hard stalls to recover from: the host line-queue emulation occasionally wedges, so
// drop a frame and carry on; give up if it keeps happening.
#define HOST_STALL_MAX_RECOVERIES 20

// 一帧最多补几行空白。超过就认定这一帧没救、剩下的直接补零收尾：健康的帧一行都不补，
// 偶尔补一两行是调度抖动，补到几十行就说明行队列串路了 —— 那时**逐行等超时**会把一帧
// 拖成十几分钟，主循环卡在 lcd_do_update 里，表现成"所有点击都没反应"（实测）。
// How many blank lines one frame may absorb. Past this the frame is declared dead and the rest
// is zero-filled without waiting: a healthy frame blanks none, one or two is scheduling jitter,
// and dozens mean the line queues crossed over -- and waiting per line turns one frame into tens
// of minutes while the main loop sits in lcd_do_update (measured: nothing reacted at all).
#define HOST_MAX_BLANK_PER_FRAME 8

static const char* TAG = "lcd_host";

static int s_display_width;
static int s_display_height;
static int s_pixel_clock_hz;
static LcdLineTiming_t s_line_timing;
static bool s_initialized;

static line_cb_func_t s_line_cb;
static void* s_line_cb_payload;
static frame_done_func_t s_frame_done_cb;
static void* s_frame_done_payload;

/* ---- 刷新结束导出钩子 / End-of-refresh export hook ---- */

// 官方 render_lcd.c 的 lcd_do_update 会为每条波形帧调一次 epd_lcd_start_frame，
// 全部帧跑完才把两个回调清成 NULL（render_lcd.c:96-97）。导出必须刚好落在
// "最后一帧消费完、主线程还没拿回控制权"的时刻：那时 framebuffer 是本轮的最终
// 画面且不会被改写。主线程一旦从 lcd_do_update 返回，应用可能马上开始画下一帧。
//
// 判定"最后一帧"用 ctx->current_frame：主循环只在 frame_done 交回后才自增
// （render_lcd.c:90），所以消费者看到 current_frame == cycle_frames-1 就是最后一帧。
//
// The official lcd_do_update starts one LCD frame per waveform phase and only
// nulls both callbacks after the last one (render_lcd.c:96-97). The export must
// land exactly when the last frame is consumed and the main thread is still
// blocked, because that is when the framebuffer holds the final image and is not
// yet being redrawn.
static uint8_t* s_framebuffer;
static void (*s_export_cb)(uint8_t* fb, void* user);
static void* s_export_user;
static pthread_t s_control_thread;
/// 这一帧的 start_frame 是不是主线程直接发的（push_pixels 闪屏路径）。
/// / Whether this frame's start_frame came from the control thread (push_pixels).
static bool s_frame_from_control_thread;
static int s_exports;

void host_lcd_set_framebuffer(uint8_t* fb) {
    s_framebuffer = fb;
}

void host_lcd_set_export(void (*cb)(uint8_t* fb, void* user), void* user) {
    s_export_cb = cb;
    s_export_user = user;
}

// 一帧一个消费者线程，由「帧代号」判定重复触发：lcd_do_update 每完成一帧才把
// ctx->current_frame 加一，而两路喂数任务都会在同一帧里调 start_frame，所以
// 同代号 = 重复触发（忽略），新代号 = 新帧（等上一帧消费者收尾后另起一个线程）。
// 上一帧消费者在回调 frame_done 之前会先登记空闲并广播，因此这里的等待不引入
// 额外延迟，也不会和官方「回调里清空回调指针」的写法互相覆盖。
static pthread_mutex_t s_frame_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_frame_idle = PTHREAD_COND_INITIALIZER;
static bool s_frame_active;
static int s_last_generation = -1;
static int s_frames_started;
static int s_recoveries;  ///< 硬卡死恢复次数 / hard-stall recoveries so far
static int s_underruns;
/// 1 = 打印每帧明细，排查刷屏问题时用。
static int s_verbose;
/// 最近一次渲染上下文，卡死时用来 dump 状态。
static RenderContext_t* s_ctx;
/// 消费者为了让出调度权自旋的次数，用来判断谁在等谁。
static long s_spins;

void epd_lcd_frame_done_cb(frame_done_func_t cb, void* payload) {
    s_frame_done_cb = cb;
    s_frame_done_payload = payload;
}

void epd_lcd_line_source_cb(line_cb_func_t cb, void* payload) {
    s_line_cb = cb;
    s_line_cb_payload = payload;
}

// 等待策略：macOS 上 nanosleep(20µs) 实际睡约 1ms，sched_yield() 在无同优先级
// 可运行线程时也要约 1ms —— 两者都会把一帧 684 行拖成秒级。这里用纯自旋等数据
// （喂数线程通常已经跑在前面），但每 128 次就让出一次：让出太稀疏会把喂数线程
// 饿死，等的人反而等更久（实测 687/688 行自旋 20ms 等到欠载）。
// Waiting strategy: on macOS both nanosleep(20us) and sched_yield() cost about a
// millisecond, which turns a 684-line frame into seconds. Spin instead, but yield
// every 128 calls: yielding too rarely starves the feeder and the waiter ends up
// waiting longer (687/688 lines spun 20 ms into a declared underrun).
static void yield_once(void) {
    static unsigned counter;
    for (volatile int i = 0; i < 200; i++) {
        // 纯自旋，等喂数线程把行放进队列。
    }
    if ((++counter & 0x7F) == 0) {
        sched_yield();
    }
}

/// 等这一行的数据出现在行队列里。真机上这是 DMA 等喂数线程。
///
/// push_pixels 路径（闪屏 / epd_clear / 锁屏前那一下）**根本不往行队列写**，所以必须
/// 放行。原来靠 `lines_prepared == 0` 判断，但那个假设是错的：epd_push_pixels_lcd
/// 只重置 lines_total 与 lines_consumed（render_lcd.c:154-156），**不重置
/// lines_prepared**，于是它一直留着上一内容帧的 690 → 判断失效 → 消费者去等一个永远
/// 不会被填的队列，每一行都等到超时。实测就是这样：锁屏前的 epd_clear 之后，后面每一帧
/// 都判死、不导出，预览冻在最后一张画面上。现在由调用方按 from_control 显式跳过等待。
///
/// The push_pixels path (flash / epd_clear / the one before the lock screen) never writes to the
/// line queues, so it must not wait. The old test was `lines_prepared == 0`, which is wrong:
/// epd_push_pixels_lcd resets lines_total and lines_consumed (render_lcd.c:154-156) but **not**
/// lines_prepared, so it keeps the previous content frame's 690 and the test fails -- the consumer
/// then waits on a queue that will never be filled, one timeout per line. That is exactly what
/// happened: after the epd_clear before the lock screen every later frame was declared dead and
/// nothing was exported, freezing the preview on its last picture. The caller now skips the wait
/// explicitly via from_control.
///
/// native 构建副本将每帧 owner 初始化为未发布，生产线程原子发布实际 owner。
/// 计数只表示认领，不能证明 owner 或队列数据已发布。
/// Native build copies initialize owners as unpublished and atomically publish actual owners.
/// The counter only records claims, not publication of owners or queued data.
static bool wait_line_ready(RenderContext_t* ctx, int y) {
    if (ctx == NULL) return true;
    if (atomic_load_explicit(&ctx->lines_prepared, memory_order_acquire) == 0) return true;

    // 耐心值按真实墙钟算，不按自旋次数：sched_yield() 的代价在不同负载下能差几个
    // 数量级，按次数算会让"等多久"随让出策略漂移。esp_timer_get_time() 在 macOS 上
    // 走 clock_gettime，开销可忽略。
    // Patience is measured on the real clock, not in spin counts: sched_yield()'s
    // cost varies by orders of magnitude with load, so counting calls makes "how
    // long we wait" drift with the yield policy. clock_gettime is cheap on macOS.
    const int64_t t0_us = esp_timer_get_time();
    const int64_t limit_us = (int64_t)HOST_LINE_WAIT_MS * 1000;

    // 领先量只到实际行数，不能等两条生产线程退出时的额外自增。
    // 一路可能仍堵在满队列上；消费者等其退出会形成循环依赖。
    // Cap the lead at actual rows, not the extra claims made when feeders exit.
    // A feeder may still be blocked on its full queue; waiting for its exit deadlocks.
    const int prepared_ceiling = ctx->lines_total;
    int need = y + HOST_LINE_LEAD;
    if (need > prepared_ceiling) need = prepared_ceiling;
    while (atomic_load_explicit(&ctx->lines_prepared, memory_order_acquire) < need) {
        if (esp_timer_get_time() - t0_us >= limit_us) {
            s_underruns += 1;
            ESP_LOGW(TAG, "line %d never claimed within %d ms (prepared=%d need=%d)",
                     y, HOST_LINE_WAIT_MS, atomic_load(&ctx->lines_prepared), need);
            return false;
        }
        yield_once();
        s_spins += 1;
    }

    // native 每帧 owner 先为 UINT8_MAX；喂数线程认领后 release 发布实际 owner。
    // 不以行号预设另一条队列，计数自增早于 owner 发布，二者不能互相替代。
    // Native owners start as UINT8_MAX and feeders publish the actual owner with release.
    // A claim counter increment precedes publication and cannot substitute for it.
    int thread = 0;
    if (ctx->line_threads != NULL) {
        while ((thread = __atomic_load_n(&ctx->line_threads[y], __ATOMIC_ACQUIRE))
               >= NUM_RENDER_THREADS) {
            if (esp_timer_get_time() - t0_us >= limit_us) {
                s_underruns += 1;
                ESP_LOGW(TAG, "line %d owner not published within %d ms", y, HOST_LINE_WAIT_MS);
                return false;
            }
            yield_once();
        }
    }

    LineQueue_t* lq = &ctx->line_queues[thread];
    while (atomic_load_explicit(&lq->current, memory_order_acquire)
           == atomic_load_explicit(&lq->last, memory_order_acquire)) {
        if (ctx->line_threads != NULL) {
            const int now_owner = __atomic_load_n(&ctx->line_threads[y], __ATOMIC_ACQUIRE);
            if (now_owner >= 0 && now_owner < NUM_RENDER_THREADS && now_owner != thread) {
                thread = now_owner;
                lq = &ctx->line_queues[thread];
                continue;
            }
        }
        if (esp_timer_get_time() - t0_us >= limit_us) {
            s_underruns += 1;
            // consumed 是官方 retrieve_line_isr 自己数的行号：它必须等于我们这里的 y，
            // 否则两边读的不是同一条队列 —— 那才是欠载的真因。
            // consumed is the line index the official retrieve_line_isr counts; it must
            // equal our y, otherwise the two sides read different queues.
            ESP_LOGW(TAG,
                     "stall: line %d consumed=%d owner %d q(cur=%d last=%d size=%d) "
                     "prepared=%d total=%d err=0x%x",
                     y, ctx->lines_consumed, thread, atomic_load(&lq->current),
                     atomic_load(&lq->last), lq->size, atomic_load(&ctx->lines_prepared),
                     ctx->lines_total, (unsigned)ctx->error);
            return false;
        }
        yield_once();
        s_spins += 1;
    }
    return true;
}

/// 所有渲染队列都空了吗？喂数线程一帧提交完就收工，此时若消费者的目标队列是空的，
/// 那这一帧剩下的行**永远不会来**。
/// Are all render queues empty? Once the feeders finish a frame they stop, so if the consumer's
/// target queue is empty the remaining lines of this frame will never arrive.
static bool all_queues_empty(RenderContext_t* ctx) {
    if (ctx == NULL) return false;
    for (int i = 0; i < NUM_RENDER_THREADS; i++) {
        if (atomic_load(&ctx->line_queues[i].current)
            != atomic_load(&ctx->line_queues[i].last)) {
            return false;
        }
    }
    return true;
}

static void* lcd_thread_main(void* arg) {
    RenderContext_t* ctx = (RenderContext_t*)arg;
    uint8_t line[HOST_LINE_BYTES_MAX];
    int consumed = 0;
    const int64_t t_start = esp_timer_get_time();
    // 回调必须在开头捕获：官方 handle_lcd_frame_done 第一件事就是把全局回调清空，
    // 结尾再读就可能读到下一帧刚注册的处理器。
    frame_done_func_t done = s_frame_done_cb;
    void* done_payload = s_frame_done_payload;
    // 同理：本帧的"是否内容帧"也要在开头捕获，可能被下一帧覆盖。
    const bool from_control = s_frame_from_control_thread;

    // 真机的行数由 lines_total 决定（688），比可见高度 684 多出帧尾补齐行；
    // 少消费这几行会让行队列逐帧堆积，最终把喂数线程卡在满队列上。
    const int lines_to_consume = ctx != NULL && ctx->lines_total > 0
        ? ctx->lines_total : s_display_height;

    // 故障注入（仅 host）：让**第一帧**在消费前先卡住一段时间，用来验证
    // "看门狗判定卡死 → 丢掉这一帧 → 继续跑下面几帧"这条恢复路径。真机上没有这条路径
    // （行数据来自 DMA），而它平时只在那场偶发的行队列卡死里才会走到 —— 等于没测过。
    // Fault injection (host only): wedge the *first* frame before consuming, so the
    // "watchdog detects a stall -> drop the frame -> keep running" recovery path can be tested.
    // The board has no such path (lines come from DMA), and normally this only triggers on a rare
    // line-queue wedge, which means it would never be tested at all.
    static int s_wedged;
    const char* wedge_ms = getenv("PAPERLAB_WEDGE_ONCE_MS");
    if (!s_wedged && wedge_ms != NULL && wedge_ms[0] != '\0') {
        s_wedged = 1;
        const long ms = strtol(wedge_ms, NULL, 10);
        struct timespec nap = {
            .tv_sec = ms / 1000,
            .tv_nsec = (ms % 1000) * 1000000L,
        };
        fprintf(stderr, "[lcd_host] injected a %ld ms wedge to exercise stall recovery\n", ms);
        fflush(stderr);
        nanosleep(&nap, NULL);
    }

    bool blanked = false;  // 本帧补过空白行 / this frame blanked at least one line
    // 这一帧是否已经判定为"没救了"。行队列偶尔会串到另一路（见 wait_line_ready 的说明），
    // 此时消费者等的队列永远不会来数据 —— 而**逐行等超时**会把一帧拖成几百个超时，
    // 682 行就是十几分钟，期间主循环一直卡在 lcd_do_update 里，表现成"开机后所有点击
    // 都不再有反应"（实测）。一旦连续两次超时且所有队列都空，就认定本帧已死，剩下的行
    // 直接补零收尾 —— 丢一帧远好过冻住整场。
    // Whether this frame is already known to be dead. The line queues occasionally cross over to
    // the other render thread (see the note in wait_line_ready); the queue the consumer waits on
    // then never receives data, and waiting per line turns one frame into hundreds of timeouts
    // (682 lines = tens of minutes) during which the main loop sits inside lcd_do_update and the
    // whole UI looks unresponsive (measured: nothing reacted after boot). After two consecutive
    // timeouts with every queue empty, declare the frame dead and blank the rest without waiting
    // -- dropping one frame beats freezing the session.
    bool frame_dead = false;
    int dead_strikes = 0;
    int blanked_lines = 0;
    for (int y = 0; y < lines_to_consume; y++) {
        // push_pixels 帧（闪屏 / epd_clear / 锁屏前那一下）的数据来自 push_pixels_isr，
        // **不在行队列里**，所以一行都不能等 —— 见 wait_line_ready 上面的说明。
        // 仍然照常调用回调，让面板数据路径与真机一致。
        // A push_pixels frame's data comes from push_pixels_isr, not from the line queues, so
        // nothing may be waited for (see the note above wait_line_ready). The callback is still
        // invoked so the panel data path matches the device.
        if (from_control) {
            memset(line, 0, (size_t)(s_display_width / 4));
            if (s_line_cb != NULL) {
                s_line_cb(s_line_cb_payload, line);
            }
            if (ctx != NULL) ctx->lines_consumed = y + 1;
            consumed += 1;
            continue;
        }
        if (frame_dead) {
            memset(line, 0, (size_t)(s_display_width / 4));
            const int dead_owner = ctx->line_threads != NULL ? ctx->line_threads[y] : 0;
            if (dead_owner >= 0 && dead_owner < NUM_RENDER_THREADS) {
                uint8_t discard[HOST_LINE_BYTES_MAX];
                (void)lq_read(&ctx->line_queues[dead_owner], discard);
            }
            ctx->lines_consumed = y + 1;
            consumed += 1;
            continue;
        }
        // 包括帧尾补齐行在内，每行都必须等待发布并由同一个回调消费一次。
        // 不等待的尾行取走会漏掉尚未提交的行，污染下一帧队列。
        // Wait for publication and consume every row exactly once, including padding.
        // Nonblocking tail drains miss pending commits and contaminate the next frame.
        if (!wait_line_ready(ctx, y)) {
            // 真实行没等到数据。**故意不置 ctx->error**：官方 guard_draw_result 一见
            // 这个标志就把 pclk 降到 12 MHz 并整屏刷白（display.c:173-185），代价是丢
            // 掉整个画面；而这里缺的只是极少数行，补一行空白远好过整屏白。
            // 仍然记一条告警 + 计数，真机上要查的问题不会被藏掉。
            //
            // A real line did not arrive. Deliberately do NOT set ctx->error: the
            // official guard_draw_result reacts by dropping pclk to 12 MHz and wiping
            // the panel white (display.c:173-185), which costs the whole frame. Losing
            // a line to blanking is far cheaper. The warning and the counter keep the
            // underlying problem visible.
            ESP_LOGW(TAG, "line %d missing, blanking it (frame %d, %d/%d)",
                     y, ctx != NULL ? ctx->current_frame : -1, consumed, lines_to_consume);
            blanked_lines += 1;
            // 两条判据，任一成立就认定本帧已死：一是连续两次超时且所有队列都空（喂数线程
            // 已收工），二是**本帧补零的行数超过上限** —— 后者与队列状态无关，是个硬上限，
            // 保证"逐行等超时"最多只发生 HOST_MAX_BLANK_PER_FRAME 次。
            // Two conditions, either one kills the frame: two consecutive timeouts with every
            // queue empty (the feeders are done), or the frame has already blanked more than a
            // hard cap. The cap does not depend on queue state, so "one timeout per line" can
            // happen at most HOST_MAX_BLANK_PER_FRAME times.
            const bool queues_drained = all_queues_empty(ctx);
            dead_strikes = queues_drained ? dead_strikes + 1 : 0;
            if (dead_strikes >= 2 || blanked_lines > HOST_MAX_BLANK_PER_FRAME) {
                frame_dead = true;
                ESP_LOGW(TAG,
                         "frame %d is dead at line %d (%d blanked, queues %s): the remaining "
                         "%d lines cannot arrive; blanking them without waiting",
                         ctx != NULL ? ctx->current_frame : -1, y, blanked_lines,
                         queues_drained ? "empty" : "not empty", lines_to_consume - y);
            }
            memset(line, 0, (size_t)(s_display_width / 4));
            blanked = true;
            consumed += 1;
            continue;
        }
        if (s_line_cb != NULL) {
            // 官方 retrieve_line_isr 读到空队列时会自己置 EPD_DRAW_EMPTY_LINE_QUEUE。
            // 那是本帧的第一个真故障点，记下来（只报一次），后面就都是它的连锁反应。
            // The official retrieve_line_isr sets EPD_DRAW_EMPTY_LINE_QUEUE itself when
            // it reads an empty queue. That is the first real fault in the frame, so
            // report it once; everything after it is fallout.
            const unsigned before = ctx != NULL ? (unsigned)ctx->error : 0u;
            s_line_cb(s_line_cb_payload, line);
            if (ctx != NULL && before == 0u && (unsigned)ctx->error != 0u) {
                ESP_LOGW(TAG, "first fault at line %d: error=0x%x (prepared=%d total=%d)",
                         y, (unsigned)ctx->error, atomic_load(&ctx->lines_prepared),
                         ctx->lines_total);
            }
        }
        consumed += 1;
    }

    // 本帧补过空白行的话，清掉官方 retrieve_line_isr 在空队列上置的
    // EPD_DRAW_EMPTY_LINE_QUEUE。喂数线程被操作系统延迟几毫秒就会触发它，那不是面板
    // 错误；而这个标志是**粘的**：留着它，官方 guard_draw_result 会把 pclk 降到 12 MHz
    // 并整屏刷白，之后每一帧都在"error flag is set"上早退 —— 预览就永久冻在第一屏
    // （实测遇到过一次：开机后所有点击都不再改画面）。补空白只丢一行，冻住丢整场。
    // Clear the sticky flag the official retrieve_line_isr sets on an empty queue once we
    // have blanked a line: a few milliseconds of OS scheduling delay on the feeder thread
    // is not a panel error. Left set, guard_draw_result drops pclk to 12 MHz and wipes the
    // panel white, and every later frame early-outs, freezing the preview on its first
    // screen (observed once: nothing repainted after boot). Blanking costs one line.
    if (blanked && ctx != NULL) {
        const unsigned sticky = (unsigned)EPD_DRAW_EMPTY_LINE_QUEUE;
        if (((unsigned)ctx->error & sticky) != 0) {
            ctx->error = (enum EpdDrawError)((unsigned)ctx->error & ~sticky);
            ESP_LOGW(TAG, "cleared EPD_DRAW_EMPTY_LINE_QUEUE after blanking (host emulation)");
        }
    }

    // 内容帧的最后一帧：在交回 frame_done 之前导出。此刻主线程还阻塞在
    // lcd_do_update 的 xSemaphoreTake(frame_done) 上，framebuffer 是最终画面。
    // push_pixels 闪屏路径不走这里（from_control），它不改画面内容。
    if (!from_control && ctx != NULL && ctx->cycle_frames > 0
        && ctx->current_frame + 1 >= ctx->cycle_frames && s_export_cb != NULL) {
        s_exports += 1;
        s_export_cb(s_framebuffer, s_export_user);
    }

    // 先登记空闲并广播（此时本帧已消费完），再回调 frame_done 唤醒主循环。
    pthread_mutex_lock(&s_frame_lock);
    s_frame_active = false;
    pthread_cond_broadcast(&s_frame_idle);
    pthread_mutex_unlock(&s_frame_lock);

    if (done != NULL) {
        done(done_payload);
    }

    const int64_t t_end = esp_timer_get_time();
    if (s_verbose || consumed < lines_to_consume) {
        ESP_LOGI(TAG, "frame consumed %d/%d lines in %.2f ms (spins %ld)",
                 consumed, lines_to_consume, (double)(t_end - t_start) / 1000.0, s_spins);
    }
    return NULL;
}

void epd_lcd_start_frame(void) {
    if (!s_initialized) {
        ESP_LOGE(TAG, "start_frame before init");
        return;
    }

    // 帧代号：lcd_do_update 每完成一帧才把 ctx->current_frame 加一，而两路喂数任务
    // 都会在同一帧里触发一次 start_frame，所以同代号 = 重复触发（忽略），新代号 =
    // 新帧（等上一帧消费者收尾后另起线程）。
    // Generation: current_frame only advances once a frame completes, so an equal
    // generation is the second feeder's duplicate trigger, a new one is a new frame.
    RenderContext_t* ctx = (RenderContext_t*)s_line_cb_payload;
    const int generation = ctx != NULL ? ctx->current_frame : s_frames_started;

    pthread_mutex_lock(&s_frame_lock);
    // 同一帧的重复触发：只有在这一帧还没跑完、且代号相同的时候才算重复。
    // 早期版本只比代号，结果 epd_push_pixels_lcd 每次都把 current_frame 置 0
    // （render_lcd.c:154），第二次闪屏就被当成重复吃掉，主线程永远等不到
    // frame_done —— epd_clear() 直接死锁。加上 s_frame_active 之后，闪屏与
    // 单相位 DU 这类"同一代号连续两轮"的更新都能正常起帧。
    // Duplicate trigger of the *same in-flight* frame: require both an active
    // frame and an equal generation. Comparing the generation alone deadlocked
    // epd_clear(), because epd_push_pixels_lcd resets current_frame to 0 every
    // call (render_lcd.c:154) so the second flash looked like a duplicate.
    if (s_frame_active && generation == s_last_generation) {
        pthread_mutex_unlock(&s_frame_lock);
        return;
    }
    while (s_frame_active) {
        // 上一帧的消费者正在收尾（它已消费完，不会再等这一帧的数据），让出即可。
        pthread_cond_wait(&s_frame_idle, &s_frame_lock);
    }
    s_frame_active = true;
    s_last_generation = generation;
    s_frames_started += 1;
    pthread_mutex_unlock(&s_frame_lock);

    if (s_verbose) {
        static int64_t t_first;
        const int64_t now = esp_timer_get_time();
        if (t_first == 0) t_first = now;
        ESP_LOGI(TAG, "start_frame #%d (gen %d) at %.2f ms", s_frames_started, generation,
                 (double)(now - t_first) / 1000.0);
    }

    s_ctx = ctx;

    // 记录本帧是谁触发的：内容帧由喂数任务触发，闪屏由主线程直接触发。
    // Record who started this frame: feeders for content, the control thread for push_pixels.
    s_frame_from_control_thread = pthread_equal(pthread_self(), s_control_thread);

    pthread_t t;
    if (pthread_create(&t, NULL, lcd_thread_main, s_line_cb_payload) != 0) {
        ESP_LOGE(TAG, "cannot create LCD consumer thread");
        pthread_mutex_lock(&s_frame_lock);
        s_frame_active = false;
        pthread_cond_broadcast(&s_frame_idle);
        pthread_mutex_unlock(&s_frame_lock);
        return;
    }
    pthread_detach(t);
}

/// 卡死判定的超时。可用 PAPERLAB_STALL_TIMEOUT_MS 调小，好让"恢复"这条路径能被**直接测到**
/// （否则只能等那场偶发的行队列卡死，等于没测）。
/// The stall timeout. PAPERLAB_STALL_TIMEOUT_MS can lower it so the recovery path can be tested
/// directly instead of waiting for a rare line-queue wedge.
static int stall_timeout_ms(void) {
    const char* env = getenv("PAPERLAB_STALL_TIMEOUT_MS");
    if (env != NULL && env[0] != '\0') {
        const int value = atoi(env);
        if (value >= 10) return value;
    }
    return HOST_STALL_TIMEOUT_MS;
}

/// 卡死看门狗：只有在"有一帧正在消费"且帧号超过 HOST_STALL_TIMEOUT_MS 没前进时
/// 才判定卡死。交互式主循环里画面可以长时间不动（app_loop 空闲时本来就不刷屏），
/// 所以"没有新帧"本身不是异常——早期只看帧号的版本会把空闲的模拟器误杀。
/// 真机上这种情况由 DMA 欠载报错处理；模拟器里要能一眼看出卡在哪。
/// Stall watchdog: only fires while a frame is actually being consumed and the
/// frame counter has not moved for HOST_STALL_TIMEOUT_MS. An idle UI legitimately
/// draws nothing, so "no new frame" alone is not a fault; the earlier version that
/// watched the counter alone killed an idle simulator.
static void* stall_watchdog(void* arg) {
    (void)arg;
    int last = -1;
    int stuck_ms = 0;
    for (;;) {
        struct timespec ts = { .tv_sec = 0, .tv_nsec = 200 * 1000 * 1000L };
        nanosleep(&ts, NULL);
        if (!s_frame_active) {
            // 空闲：没有帧在飞，重置计时。/ Idle: no frame in flight, reset.
            last = s_frames_started;
            stuck_ms = 0;
            continue;
        }
        if (s_frames_started != last) {
            last = s_frames_started;
            stuck_ms = 0;
            continue;
        }
        stuck_ms += 200;
        if (stuck_ms < stall_timeout_ms()) continue;

        RenderContext_t* c = s_ctx;
        fprintf(stderr, "[lcd_host] STALL: frames=%d gen=%d active=%d\n",
                s_frames_started, c != NULL ? c->current_frame : -1, (int)s_frame_active);
        if (c != NULL) {
            fprintf(stderr, "  prepared=%d consumed=%d total=%d cycle=%d error=0x%x\n",
                    atomic_load(&c->lines_prepared), c->lines_consumed, c->lines_total,
                    c->cycle_frames, (unsigned)c->error);
            for (int i = 0; i < NUM_RENDER_THREADS; i++) {
                fprintf(stderr, "  q[%d] cur=%d last=%d size=%d\n", i,
                        atomic_load(&c->line_queues[i].current),
                        atomic_load(&c->line_queues[i].last), c->line_queues[i].size);
            }
            fprintf(stderr, "  line_threads[%d..%d]=%d,%d,%d\n",
                    c->lines_consumed - 1, c->lines_consumed + 1,
                    c->line_threads[c->lines_consumed - 1],
                    c->line_threads[c->lines_consumed], c->line_threads[c->lines_consumed + 1]);
        }
        fflush(stderr);

        // 不再直接 _exit(2)：这条路径只存在于 host 仿真（真机有 DMA），而代价是**整场预览
        // 消失**、回归也跟着失败。丢一帧远好过丢整场：清掉错误标志、把这一帧标记为结束并
        // 广播，等在 start_frame 里的喂数线程就能继续喂下一帧，而下一帧会整屏重绘。
        // 只恢复有限次：真到了每帧都卡死，还是要明确失败，别把问题藏起来。
        //
        // Do not _exit(2): this path exists only in the host emulation (the board has real DMA)
        // and the price is losing the whole preview plus a failing regression. Losing one frame
        // beats losing the session: clear the error flag, mark the frame done and broadcast so the
        // feeders waiting in start_frame resume, and the next frame repaints everything. Recover
        // only a bounded number of times -- if every frame stalls, fail loudly instead of hiding it.
        s_recoveries += 1;
        if (s_recoveries > HOST_STALL_MAX_RECOVERIES) {
            fprintf(stderr, "[lcd_host] giving up after %d recoveries\n", s_recoveries);
            fflush(stderr);
            _exit(2);
        }
        fprintf(stderr,
                "[lcd_host] dropping the stalled frame and carrying on (recovery %d/%d)\n",
                s_recoveries, HOST_STALL_MAX_RECOVERIES);
        fflush(stderr);
        pthread_mutex_lock(&s_frame_lock);
        if (c != NULL) c->error = (enum EpdDrawError)0;
        s_frame_active = false;
        pthread_cond_broadcast(&s_frame_idle);
        pthread_mutex_unlock(&s_frame_lock);
        last = s_frames_started;
        stuck_ms = 0;
    }
    return NULL;
}

void epd_lcd_init(const LcdEpdConfig_t* config, int display_width, int display_height) {
    if (config != NULL) {
        s_pixel_clock_hz = (int)config->pixel_clock;
        s_line_timing = config->line;
    }
    s_display_width = display_width;
    s_display_height = display_height;
    s_initialized = true;
    // 控制线程 = 调 epd_lcd_init 的那个（官方在 epd_init 里调，也就是 app 主线程）。
    // 后面用它区分内容帧与 push_pixels 闪屏帧。
    // Control thread = whoever calls epd_lcd_init (epd_init, i.e. the app main
    // thread); used to tell content frames from push_pixels flashes.
    s_control_thread = pthread_self();
    {
        static int watchdog_started;
        if (!watchdog_started) {
            watchdog_started = 1;
            pthread_t w;
            if (pthread_create(&w, NULL, stall_watchdog, NULL) == 0) pthread_detach(w);
        }
    }
    ESP_LOGI(
        TAG, "host panel %dx%d, pclk %d MHz, line %d/%d/%d clocks",
        display_width, display_height, s_pixel_clock_hz / 1000000,
        s_line_timing.le_high_time, s_line_timing.line_front_porch, s_line_timing.line_end
    );
}

void epd_lcd_deinit(void) {
    s_initialized = false;
    s_line_cb = NULL;
    s_frame_done_cb = NULL;
    // 导出钩子留下不管：deinit 之后不该再有帧，真要有也是应用自己关的。
    // Leave the export hook alone: no frames follow deinit in practice.
}

void epd_lcd_set_pixel_clock_MHz(int frequency) {
    s_pixel_clock_hz = frequency * 1000000;
}

void epd_lcd_set_line_timing(const LcdLineTiming_t* timing) {
    if (timing != NULL) {
        s_line_timing = *timing;
    }
}

/* ---- 给 host 上层用的小接口 / Host-side helpers ---- */

int host_lcd_frames_started(void) {
    return s_frames_started;
}

void host_lcd_set_verbose(int on) {
    s_verbose = on ? 1 : 0;
}

int host_lcd_underruns(void) {
    return s_underruns;
}

int host_lcd_exports(void) {
    return s_exports;
}

/// 一行有多少个像素时钟：L_SL + L_BL + L_DL + L_EL，L_DL = 宽 / 每钟像素数。
int host_lcd_line_clocks(void) {
    const int px_per_clk = 8;  // 16 bit 总线、2 bit/像素
    return s_line_timing.le_high_time + s_line_timing.line_front_porch
        + s_display_width / px_per_clk + s_line_timing.line_end;
}

int host_lcd_pixel_clock_mhz(void) {
    return s_pixel_clock_hz / 1000000;
}
