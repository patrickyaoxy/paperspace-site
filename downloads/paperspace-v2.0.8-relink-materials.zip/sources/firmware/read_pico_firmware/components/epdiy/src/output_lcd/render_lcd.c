#include <stdint.h>
#include <string.h>

#include "../output_common/render_method.h"

#ifdef RENDER_METHOD_LCD

#include <esp_idf_version.h>
#include <esp_log.h>
#if ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(6, 0, 0)
#if __has_include(<rom/cache.h>)
#include <rom/cache.h>
#elif __has_include(<esp32s3/rom/cache.h>)
#include <esp32s3/rom/cache.h>
#endif
#else
#include <rom/cache.h>
#endif

#include "../epd_internals.h"
#include "../output_common/line_queue.h"
#include "../output_common/lut.h"
#include "../output_common/render_context.h"
#include "epd_board.h"
#include "epdiy.h"
#include "lcd_driver.h"
#include "render_lcd.h"
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
#include "esp_timer.h"
// 仅预生成动画测量，每相两次原子时戳；不逐行打印或改DMA/波形。
// Measure prepared animations only, with two atomic timestamps per phase; no per-line logs or DMA/waveform changes.
static struct {
    bool enabled,valid;uint32_t dispatch;
    atomic_uint started,ended,underruns;
    uint32_t queue_wait[NUM_RENDER_THREADS],queue_max[NUM_RENDER_THREADS];
    EpdLcdFrameTiming last;
} timing;
#if CONFIG_PAPERLAB_READER_DIAGNOSTICS
// 任务线程在既有扫描/喂线程完成栅栏之后汇总；ISR继续仅写原子时戳。
// Aggregate in the caller task after existing scan/feeder fences; ISR only stores existing atomic timestamps.
static struct {bool active;uint32_t begin;EpdLcdReaderTiming result;} reader_timing;
void epd_lcd_reader_timing_begin(void) {
    reader_timing.result=(EpdLcdReaderTiming){0};
    reader_timing.begin=(uint32_t)esp_timer_get_time();reader_timing.active=true;
}
EpdLcdReaderTiming epd_lcd_reader_timing_end(void) {
    reader_timing.active=false;return reader_timing.result;
}
static void reader_timing_add(uint32_t started,uint32_t ended,uint32_t underruns) {
    if(!reader_timing.active)return;
    reader_timing.result.frames++;
    if(started&&ended)reader_timing.result.scan_us+=ended-started;
    else reader_timing.result.invalid_frames++;
    // 任一无效相使整体完成时长无效；后续有效相不可恢复旧整体值。
    // Any invalid phase invalidates whole-call completion; later valid phases cannot restore it.
    reader_timing.result.complete_us=reader_timing.result.invalid_frames?0:ended-reader_timing.begin;
    reader_timing.result.underrun_lines+=underruns;
}
#endif
bool epd_lcd_last_frame_timing(EpdLcdFrameTiming* out){if(!out||!timing.valid)return false;*out=timing.last;return true;}
static void timing_start(void){if(timing.enabled)atomic_store(&timing.started,(uint32_t)esp_timer_get_time());}
static void timing_queue_wait(int thread,uint32_t begin) {
    uint32_t us=(uint32_t)esp_timer_get_time()-begin;timing.queue_wait[thread]+=us;
    if(us>timing.queue_max[thread])timing.queue_max[thread]=us;
}
#endif

// declare vector optimized line mask application.
void epd_apply_line_mask_VE(uint8_t* line, const uint8_t* mask, int mask_len);

__attribute__((optimize("O3"))) static bool IRAM_ATTR
retrieve_line_isr(void* payload, uint8_t* buf) {
    // 定义直接匹配LCD回调契约，不通过不兼容函数指针调用。
    // Match the LCD callback type directly; never call through an incompatible function pointer.
    RenderContext_t* ctx = payload;
    if (ctx->lines_consumed >= ctx->lines_total) {
        return false;
    }
    int thread = ctx->line_threads[ctx->lines_consumed];
    if (thread >= NUM_RENDER_THREADS) {
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        if(timing.enabled)atomic_fetch_add(&timing.underruns,1);
#endif
        ctx->error |= EPD_DRAW_EMPTY_LINE_QUEUE;
        memset(buf, 0x00, ctx->display_width / 4);
        ctx->lines_consumed += 1;
        return pdFALSE;
    }

    LineQueue_t* lq = &ctx->line_queues[thread];

    BaseType_t awoken = pdFALSE;

    if (lq_read(lq, buf) != 0) {
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        if(timing.enabled)atomic_fetch_add(&timing.underruns,1);
#endif
        ctx->error |= EPD_DRAW_EMPTY_LINE_QUEUE;
        memset(buf, 0x00, ctx->display_width / 4);
    }
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
    if(ctx->tile_plan&&ctx->tile_plan->producer_overlap&&ctx->feed_space[thread]) {
        int pending=(atomic_load(&lq->current)-atomic_load(&lq->last)+lq->size)%lq->size;
        if(pending<=lq->size/2)xSemaphoreGiveFromISR(ctx->feed_space[thread],&awoken);
    }
#endif

    if (ctx->lines_consumed >= ctx->display_height) {
        memset(buf, 0x00, ctx->display_width / 4);
    }
    ctx->lines_consumed += 1;
    return awoken;
}

/// start the next frame in the current update cycle
static void IRAM_ATTR handle_lcd_frame_done(void* payload) {
    RenderContext_t* ctx = payload;
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
    if(timing.enabled)atomic_store(&timing.ended,(uint32_t)esp_timer_get_time());
#endif
    epd_lcd_frame_done_cb(NULL, NULL);
    epd_lcd_line_source_cb(NULL, NULL);

    BaseType_t task_awoken = pdFALSE;
    xSemaphoreGiveFromISR(ctx->frame_done, &task_awoken);

    portYIELD_FROM_ISR();
}

void lcd_do_update(RenderContext_t* ctx) {
    epd_set_mode(1);

    for (int k = 0; k < ctx->cycle_frames; k++) {
        // 上一帧DMA和两条喂线程已经结束，允许原位打包下一帧。/ Prior DMA and both feeders have finished; packing the next frame in place is safe.
        if(ctx->frame_sequence && !ctx->frame_sequence->prepare(ctx->frame_sequence->context,ctx->current_frame))break;
        epd_lcd_frame_done_cb(handle_lcd_frame_done, ctx);
        prepare_context_for_next_frame(ctx);
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        for(int i=0;i<NUM_RENDER_THREADS;i++)if(ctx->feed_space[i])xSemaphoreTake(ctx->feed_space[i],0);
#endif
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        timing.enabled=ctx->frame_sequence||(ctx->tile_plan&&ctx->tile_plan->prepared_actions);
#if CONFIG_PAPERLAB_READER_DIAGNOSTICS
        timing.enabled=timing.enabled||reader_timing.active;
#endif
        timing.valid=false;atomic_store(&timing.started,0);atomic_store(&timing.ended,0);atomic_store(&timing.underruns,0);
        memset(timing.queue_wait,0,sizeof(timing.queue_wait));memset(timing.queue_max,0,sizeof(timing.queue_max));
        timing.dispatch=(uint32_t)esp_timer_get_time();
#endif

        // start both feeder tasks
        xTaskNotifyGive(ctx->feed_tasks[!xPortGetCoreID()]);
        xTaskNotifyGive(ctx->feed_tasks[xPortGetCoreID()]);

        // transmission is started in renderer threads, now wait util it's done
        xSemaphoreTake(ctx->frame_done, portMAX_DELAY);

        for (int i = 0; i < NUM_RENDER_THREADS; i++) {
            xSemaphoreTake(ctx->feed_done_smphr[i], portMAX_DELAY);
        }
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        uint32_t started=atomic_load(&timing.started),ended=atomic_load(&timing.ended);
        if(timing.enabled&&started&&ended) {
            timing.last=(EpdLcdFrameTiming){.prefill_us=started-timing.dispatch,.scan_us=ended-started,
                .drain_us=(uint32_t)esp_timer_get_time()-ended,.queue_wait_us=timing.queue_wait[0]+timing.queue_wait[1],
                .queue_stall_max_us=timing.queue_max[0]>timing.queue_max[1]?timing.queue_max[0]:timing.queue_max[1],
                .underrun_lines=atomic_load(&timing.underruns)};
            timing.valid=true;
        }
#if CONFIG_PAPERLAB_READER_DIAGNOSTICS
        reader_timing_add(started,ended,atomic_load(&timing.underruns));
#endif
        timing.enabled=false;
#endif

        ctx->current_frame++;

        // 连续扫描欠载后停止；普通波形仍保持原有执行行为。/ Stop failed sequences; preserve ordinary waveform execution behavior.
        if(ctx->frame_sequence && ctx->error != EPD_DRAW_SUCCESS)break;

        // make the watchdog happy.
        vTaskDelay(0);
    }

    epd_lcd_line_source_cb(NULL, NULL);
    epd_lcd_frame_done_cb(NULL, NULL);

    if(ctx->frame_sequence && ctx->error != EPD_DRAW_SUCCESS)
        for(int i=0;i<NUM_RENDER_THREADS;i++)lq_reset(&ctx->line_queues[i]);

    epd_set_mode(0);
}

__attribute__((optimize("O3"))) static bool IRAM_ATTR
push_pixels_isr(void* payload, uint8_t* buf) {
    RenderContext_t* ctx = payload;
    // Output no-op outside of drawn area
    if (ctx->lines_consumed < ctx->area.y) {
        memset(buf, 0, ctx->display_width / 4);
    } else if (ctx->lines_consumed >= ctx->area.y + ctx->area.height) {
        memset(buf, 0, ctx->display_width / 4);
    } else {
        memcpy(buf, ctx->static_line_buffer, ctx->display_width / 4);
    }
    ctx->lines_consumed += 1;
    return pdFALSE;
}

/**
 * Populate the line mask for use in epd_push_pixels.
 */
static void push_pixels_populate_line(RenderContext_t* ctx, int color) {
    // Select fill pattern by draw color
    int fill_byte = 0;
    switch (color) {
        case 0:
            fill_byte = DARK_BYTE;
            break;
        case 1:
            fill_byte = CLEAR_BYTE;
            break;
        default:
            fill_byte = 0x00;
    }

    // Compute a line mask based on the drawn area
    uint8_t* dirtyness = malloc(ctx->display_width / 2);
    assert(dirtyness != NULL);

    memset(dirtyness, 0, ctx->display_width / 2);

    for (int i = 0; i < ctx->display_width; i++) {
        if ((i >= ctx->area.x) && (i < ctx->area.x + ctx->area.width)) {
            dirtyness[i / 2] |= i % 2 ? 0xF0 : 0x0F;
        }
    }
    epd_populate_line_mask(ctx->line_mask, dirtyness, ctx->display_width / 4);

    // mask the line pattern with the populated mask
    memset(ctx->static_line_buffer, fill_byte, ctx->display_width / 4);
    epd_apply_line_mask(ctx->static_line_buffer, ctx->line_mask, ctx->display_width / 4);

    free(dirtyness);
}

void epd_push_pixels_lcd(RenderContext_t* ctx, short time, int color) {
    ctx->current_frame = 0;
    ctx->lines_total = ctx->display_height;
    ctx->lines_consumed = 0;
    ctx->static_line_buffer = malloc(ctx->display_width / 4);
    assert(ctx->static_line_buffer != NULL);

    push_pixels_populate_line(ctx, color);
    epd_lcd_frame_done_cb(handle_lcd_frame_done, ctx);
    epd_lcd_line_source_cb(push_pixels_isr, ctx);

    epd_set_mode(1);
#if CONFIG_PAPERLAB_READER_DIAGNOSTICS && defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
    timing.enabled=reader_timing.active;
    atomic_store(&timing.started,0);atomic_store(&timing.ended,0);
    timing_start();
#endif
    epd_lcd_start_frame();
    xSemaphoreTake(ctx->frame_done, portMAX_DELAY);
#if CONFIG_PAPERLAB_READER_DIAGNOSTICS && defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
    reader_timing_add(atomic_load(&timing.started),atomic_load(&timing.ended),0);
    timing.enabled=false;
#endif
    epd_set_mode(0);

    free(ctx->static_line_buffer);
    ctx->static_line_buffer = NULL;
}

#define int_min(a, b) (((a) < (b)) ? (a) : (b))

// 每帧开扫之前先算好多少行。这段预填是帧与帧之间的空档：行队列只要跑在 DMA 前面
// 就行，一行 16us 才消费一条，喂线程几微秒就算完一条，所以预填不需要很多；太少了
// 会在 ISR 延迟抖动时欠载（EPD_DRAW_EMPTY_LINE_QUEUE）。
static int s_prefill_lines = 127;

void epd_lcd_set_prefill_lines(int lines) {
    if (lines < 4) lines = 4;
    s_prefill_lines = lines;
}

int epd_lcd_prefill_lines(void) {
    return s_prefill_lines;
}
__attribute__((optimize("O3"))) void IRAM_ATTR
lcd_calculate_frame(RenderContext_t* ctx, int thread_id) {
    assert(ctx->lut_lookup_func != NULL);
    uint8_t* input_line = ctx->feed_line_buffers[thread_id];

    LineQueue_t* lq = &ctx->line_queues[thread_id];
    int l = 0;

    // if there is an error, start the frame but don't feed data.
    if (ctx->error) {
        memset(ctx->line_threads, 0, ctx->lines_total);
        epd_lcd_line_source_cb(retrieve_line_isr, ctx);
        epd_lcd_start_frame();
        ESP_LOGW("epd_lcd", "draw frame draw initiated, but an error flag is set: %X", ctx->error);
        return;
    }

    // line must be able to hold 2-pixel-per-byte or 1-pixel-per-byte data
    memset(input_line, 0x00, ctx->display_width);

    EpdRect area = ctx->area;
    int min_y, max_y, bytes_per_line, _ppB;
    const uint8_t* ptr_start;
    get_buffer_params(ctx, &bytes_per_line, &ptr_start, &min_y, &max_y, &_ppB);

    assert(area.width == ctx->display_width && area.x == 0 && !ctx->error);

    // index of the line that triggers the frame output when processed
    int trigger_line = int_min(s_prefill_lines, max_y - min_y);

    while (l = atomic_fetch_add(&ctx->lines_prepared, 1), l < ctx->lines_total) {
        ctx->line_threads[l] = thread_id;

        // queue is sufficiently filled to fill both bounce buffers, frame
        // can begin
        if (l - min_y == trigger_line) {
            epd_lcd_line_source_cb(retrieve_line_isr, ctx);
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
            timing_start();
#endif
            epd_lcd_start_frame();
        }

        if (l < min_y || l >= max_y
            || (ctx->drawn_lines != NULL && !ctx->drawn_lines[l - area.y])) {
            uint8_t* buf = NULL;
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
            uint32_t neutral_wait_begin=0;
#endif
            while (buf == NULL) {
                // break in case of errors
                if (ctx->error & EPD_DRAW_EMPTY_LINE_QUEUE) {
                    lq_reset(lq);
                    return;
                };

                buf = lq_current(lq);
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
                if(!buf&&timing.enabled&&!neutral_wait_begin)neutral_wait_begin=(uint32_t)esp_timer_get_time();
                if(!buf&&ctx->tile_plan&&ctx->tile_plan->producer_overlap&&ctx->feed_space[thread_id])xSemaphoreTake(ctx->feed_space[thread_id],pdMS_TO_TICKS(1));
#endif
            }
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
            if(neutral_wait_begin)timing_queue_wait(thread_id,neutral_wait_begin);
#endif
            memset(buf, 0x00, lq->element_size);
            lq_commit(lq);
            continue;
        }

        uint32_t* lp = (uint32_t*)input_line;
        const uint8_t* ptr = ptr_start + bytes_per_line * (l - min_y);

        // 预生成路径不读原始diff/LUT，只预取打包后的动作行，降低DMA窗口的带宽压力。
        // Prepared path prefetches packed action rows, not raw diff/LUT, reducing bandwidth inside the DMA window.
        if(ctx->tile_plan&&ctx->tile_plan->prepared_actions)
            Cache_Start_DCache_Preload((uint32_t)(ctx->tile_plan->prepared_actions+(size_t)l*ctx->display_width/4),ctx->display_width/4,0);
        else Cache_Start_DCache_Preload((uint32_t)ptr, ctx->display_width, 0);

        lp = (uint32_t*)ptr;

        uint8_t* buf = NULL;
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        uint32_t wait_begin=0;
#endif
        while (buf == NULL) {
            // break in case of errors
                if (ctx->error & EPD_DRAW_EMPTY_LINE_QUEUE) {
                    lq_reset(lq);
                    return;
                };

            buf = lq_current(lq);
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
            if(!buf&&timing.enabled&&!wait_begin)wait_begin=(uint32_t)esp_timer_get_time();
            if(!buf&&ctx->tile_plan&&ctx->tile_plan->producer_overlap&&ctx->feed_space[thread_id])xSemaphoreTake(ctx->feed_space[thread_id],pdMS_TO_TICKS(1));
#endif
        }
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
        if(wait_begin)timing_queue_wait(thread_id,wait_begin);
#endif

        if(ctx->tile_plan&&ctx->tile_plan->prepared_actions)
            memcpy(buf,ctx->tile_plan->prepared_actions+(size_t)l*ctx->display_width/4,ctx->display_width/4);
        else lcd_lookup_line(ctx, lp, buf, l);

        // apply the line mask
        epd_apply_line_mask_VE(buf, ctx->line_mask, ctx->display_width / 4);

        lq_commit(lq);
    }
}

#endif
