#pragma once

#include "../output_common/render_context.h"
#include <string.h>
/// 单相S3观测；队列等待为两线程之和，不能加到墙钟耗时。/ S3 single-phase observations; summed queue waits are not additive wall time.
typedef struct {uint32_t prefill_us,scan_us,drain_us,queue_wait_us,queue_stall_max_us,underrun_lines;} EpdLcdFrameTiming;
#if CONFIG_PAPERLAB_READER_DIAGNOSTICS
/// 一次显示调用汇总；任一无效相令complete_us为零，scan_us仍为有效相部分和。/ Call aggregate: any invalid phase zeros complete_us; scan_us remains a partial sum of valid phases.
typedef struct {uint64_t scan_us;uint32_t complete_us,frames,invalid_frames,underrun_lines;} EpdLcdReaderTiming;
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
/// 由唯一显示调用线程开始/结束；无分配，不在ISR输出。/ Begin/end from the sole display caller; no allocation or ISR logs.
void epd_lcd_reader_timing_begin(void);
EpdLcdReaderTiming epd_lcd_reader_timing_end(void);
#else
static inline void epd_lcd_reader_timing_begin(void){}
static inline EpdLcdReaderTiming epd_lcd_reader_timing_end(void){return (EpdLcdReaderTiming){0};}
#endif
#endif
#if defined(ESP_PLATFORM) && !defined(PAPERLAB_NATIVE_SIMULATOR)
bool epd_lcd_last_frame_timing(EpdLcdFrameTiming* timing);
#else
// Host不能提供物理LCD计时，不修改其扫描适配。/ Host has no physical LCD timing; leave its scan adapter unchanged.
static inline bool epd_lcd_last_frame_timing(EpdLcdFrameTiming* timing){(void)timing;return false;}
#endif
// 向量核心加标量头尾，零长度核心绝不调用S3汇编。/ Vector core plus scalar tails; never call S3 assembly with zero length.
static inline void lcd_lookup_span(RenderContext_t* ctx,const uint32_t* input,uint8_t* output,const uint8_t* lut,int x,int n) {
    const int first=(x+15)&~15,last=(x+n)&~15;
    if(last>first)ctx->lut_lookup_func((const uint32_t*)((const uint8_t*)input+first),output+first/4,lut,last-first);
    for(int at=x;at<(last>first?first:x+n);at++)output[at/4]|=(uint8_t)((lut[((const uint8_t*)input)[at]*4]&3)<<(2*(at%4)));
    for(int at=last>first?last:x+n;at<x+n;at++)output[at/4]|=(uint8_t)((lut[((const uint8_t*)input)[at]*4]&3)<<(2*(at%4)));
}

/// 与host协议测试共用实际逐行相位选择，随后由生产线程施加列mask。
/// Actual line-phase selection shared with host protocol tests; feeder applies column mask next.
static inline void lcd_lookup_line(RenderContext_t* ctx,const uint32_t* input,
                                   uint8_t* output,int line) {
    if(ctx->tile_plan) {
        const EpdTilePhasePlan* p=ctx->tile_plan;const EpdRect r=p->area;
        memset(output,0,(size_t)ctx->display_width/4);
        if(line<r.y || line>=r.y+r.height)return;
        if(p->prepared_actions) {
            memcpy(output,p->prepared_actions+(size_t)line*ctx->display_width/4,(size_t)ctx->display_width/4);
            return;
        }
        int row=(line-r.y)/p->tile_height;
        if(p->row_edges) {
            row=0;
            while(row+1<p->rows && line>=p->row_edges[row+1])row++;
        }
        const uint8_t* mask=p->mask+(size_t)line*ctx->display_width/4;
        if(p->phase_axis==1) {
            int phase=p->phases[row];
            if(phase>=0&&phase<ctx->phase_lut_count)lcd_lookup_span(ctx,input,output,ctx->phase_luts[phase],r.x,r.width);
            for(int i=0;i<ctx->display_width/4;i++)output[i]&=mask[i];
            return;
        }
        if(p->phase_axis==2) {
            for(int i=0;i<p->span_count;i++)lcd_lookup_span(ctx,input,output,ctx->phase_luts[p->spans[i].phase],p->spans[i].x,p->spans[i].width);
            for(int i=0;i<ctx->display_width/4;i++)output[i]&=mask[i];
            return;
        }
        for(int col=0;col<p->columns;col++) {
            const int phase=epd_tile_phase_at(p,row,col);
            if(phase<0 || phase>=ctx->phase_lut_count)continue;
            int end_col=col+1;
            // 同相邻格合并查表，左右条带通常整行只有一次向量调用。
            // Merge adjacent equal phases; horizontal strips usually need one vector call per row.
            if(p->column_edges)while(end_col<p->columns&&epd_tile_phase_at(p,row,end_col)==phase)end_col++;
            const int x=p->column_edges?p->column_edges[col]:r.x+col*p->tile_width;
            const int n=p->column_edges?p->column_edges[end_col]-x:(x+p->tile_width>r.x+r.width?r.x+r.width-x:p->tile_width);
            if(p->column_edges) {
                lcd_lookup_span(ctx,input,output,ctx->phase_luts[phase],x,n);
                col=end_col-1;
                continue;
            }
            ctx->lut_lookup_func((const uint32_t*)((const uint8_t*)input+x),output+x/4,ctx->phase_luts[phase],n);
            for(int i=x/4;i<(x+n)/4;i++)output[i]&=mask[i];
        }
        // 每字节同时屏蔽四个像素，跨格边界共用同一全局mask。
        // Mask four pixels per byte once per row, sharing the global mask across cell edges.
        if(p->column_edges)for(int i=0;i<ctx->display_width/4;i++)output[i]&=mask[i];
        return;
    }
    const uint8_t* lut=ctx->conversion_lut;
    if(ctx->phase_luts && ctx->line_phase) {
        const int phase=ctx->line_phase[line];
        if(phase<0 || phase>=ctx->phase_lut_count) {
            memset(output,0,(size_t)ctx->display_width/4);
            return;
        }
        lut=ctx->phase_luts[phase];
    }
    ctx->lut_lookup_func(input,output,lut,ctx->display_width);
}

/**
 * Lighten / darken picels using the LCD driving method.
 */
void epd_push_pixels_lcd(RenderContext_t* ctx, short time, int color);

/**
 * Do a full update cycle with a configured context.
 */
void lcd_do_update(RenderContext_t* ctx);

/**
 * Worker thread for output calculation.
 * In LCD mode, both threads do the same thing.
 */
void lcd_calculate_frame(RenderContext_t* ctx, int thread_id);
