/* Local research adapter: browser command queue, no network socket or device access. */
#include <emscripten.h>
#include <pthread.h>
#include <sys/socket.h>
#include <stdatomic.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
#include "system_font.h"
#define VIRTUAL_BASE 61000
#define QUEUE_COUNT 16
static pthread_mutex_t command_lock=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t command_ready=PTHREAD_COND_INITIALIZER;
static char commands[QUEUE_COUNT][512];
static char staging[512];
static unsigned head,tail,count;
static atomic_int next_fd=VIRTUAL_BASE;
static int listener_fd=-1;
static int valid_command(const char* s){
 int x,y,x2,y2,ms;char extra,key[16];unsigned long long ticket;
 if(sscanf(s,"ARM TAP %d %d %d %c",&x,&y,&ms,&extra)==3)
  return x>=0&&x<684&&y>=0&&y<1216&&ms>=40&&ms<=1600;
 if(sscanf(s,"ARM SWIPE %d %d %d %d %d %c",&x,&y,&x2,&y2,&ms,&extra)==5)
  return x>=0&&x<684&&x2>=0&&x2<684&&y>=0&&y<1216&&y2>=0&&y2<1216&&ms>=40&&ms<=1600;
 if(sscanf(s,"KEY %15s %d %c",key,&ms,&extra)==2)
  return (!strcmp(key,"KEY1")||!strcmp(key,"KEY2")||!strcmp(key,"KEY3")||!strcmp(key,"POWER"))&&ms>=40&&ms<=1600;
 if(sscanf(s,"OBSERVE %llu %c",&ticket,&extra)==1)return ticket>0;
 return !strcmp(s,"QUIT");
}
EMSCRIPTEN_KEEPALIVE char* web_command_buffer(void){return staging;}
EMSCRIPTEN_KEEPALIVE int web_enqueue_command(void){
 size_t n=strnlen(staging,sizeof(staging));if(!n||n>=sizeof(staging))return -1;
 if(!valid_command(staging))return -1;
 if(pthread_mutex_trylock(&command_lock))return 0;
 if(count==QUEUE_COUNT){pthread_mutex_unlock(&command_lock);return 0;}
 memcpy(commands[tail],staging,n+1);tail=(tail+1)%QUEUE_COUNT;count++;
 pthread_cond_signal(&command_ready);pthread_mutex_unlock(&command_lock);return 1;
}
int __real_close(int fd);
int __wrap_socket(int domain,int type,int protocol){if(domain!=AF_INET||type!=SOCK_DGRAM){errno=ENOSYS;return -1;}return atomic_fetch_add(&next_fd,1);}
int __wrap_bind(int fd,const struct sockaddr* addr,socklen_t len){if(fd<VIRTUAL_BASE){errno=ENOSYS;return -1;}listener_fd=fd;return 0;}
ssize_t __wrap_recv(int fd,void* buf,size_t length,int flags){
 if(fd!=listener_fd){errno=EBADF;return -1;}
 pthread_mutex_lock(&command_lock);while(!count)pthread_cond_wait(&command_ready,&command_lock);
 size_t n=strlen(commands[head]);if(n>length)n=length;memcpy(buf,commands[head],n);head=(head+1)%QUEUE_COUNT;count--;
 pthread_mutex_unlock(&command_lock);
 if(n>=8&&!memcmp(buf,"OBSERVE ",8)){
  const int status=(int)system_font_change_status(NULL,NULL,NULL,NULL);
  const unsigned generation=(unsigned)system_font_generation();
  const char* path=system_font_path();
  printf("web_font: status=%d generation=%u path=%s\n",status,generation,path);
 }
 return (ssize_t)n;
}
ssize_t __wrap_sendto(int fd,const void* data,size_t n,int flags,const struct sockaddr* addr,socklen_t len){if(fd<VIRTUAL_BASE){errno=ENOSYS;return -1;}return (ssize_t)n;}
int __wrap_close(int fd){return fd>=VIRTUAL_BASE?0:__real_close(fd);}

#ifdef __cplusplus
}
#endif
