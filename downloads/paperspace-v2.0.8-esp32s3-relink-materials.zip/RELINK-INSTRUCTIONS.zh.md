# paperspace 2.0.8：ESP32-S3 Linux 重链接材料

本材料绑定应用提交 `79f2f5ad303b9a588d551e3e0eb4b6e5735bc56b`、官方 ESP-IDF v6.1 提交 `fff9895c82d744c7237be8847347bdd1b07c6643`。这是 ESP32-S3 产品配置的硬件固件对象，不是浏览器 WASM 对象。私有应用 C/C++ 源码没有包含在内；`sources/epdiy/` 是所用 LGPL 库的完整修改版源码，`sdk/` 包含必要 SDK 头文件、链接脚本和链接库。

正式交付镜像由公开对象和同一条重链命令生成：所有提供的 `.a/.o/.obj` 已移除 DWARF，最终 ELF 使用链接器 `--strip-debug` 生成。没有通过二进制替换修改运行数据、ELF 摘要或校验。链接符号和重定位保留；编译实现仍可被检查。

## 环境

已在 Linux x86-64、Python 3.12.14 实测。其他操作系统和架构未验证。

1. 下载官方 [Xtensa ESP GCC esp-15.2.0_20251204 Linux x86-64 工具链](https://github.com/espressif/crosstool-NG/releases/download/esp-15.2.0_20251204/xtensa-esp-elf-15.2.0_20251204-x86_64-linux-gnu.tar.xz)。下载文件 SHA-256 必须为 `3d50f5cd5f173acfd524e07c1cd69bc99585731a415ca2e5bce879997fe602b8`。解压后将其 `xtensa-esp-elf/bin` 绝对路径记作 `$TCBIN`。
2. 建立 Python 虚拟环境并安装随附 `requirements-relink.txt`：`python3 -m venv .venv`，然后 `.venv/bin/python -m pip install -r requirements-relink.txt`。该操作只安装本地重链工具，不连接任何设备。
3. 保留原始解压副本。`python3 relink.py --toolchain-bin "$TCBIN" --verify-only` 校验全部原始材料。此模式不需要 esptool；实际重链还会核编译器版本、esptool 版本以及 GCC 隐式读取的四个运行库原始 SHA-256。

SDK 全源码、私有应用源码、原始构建目录、CMake/Ninja 均不需要参与重链。匹配的官方工具链仍提供编译器内部头文件、默认 specs 与运行库；实际使用的 picolibc `libc/libm`、GCC `libgcc`、C++ `libstdc++` 精确身份在 `relink-plan.json`，本包也提供了去除调试信息的审计副本。应用和 SDK 的全部显式链接输入及链接参数已在包内，顺序、重复归档和符号强制引入参数均保留。

## 基线重链

在解压目录执行（输出目录必须不存在）：

```sh
python3 relink.py --toolchain-bin "$TCBIN" --python "$PWD/.venv/bin/python" --output "$PWD/../relinked-baseline"
```

输出 `Read_Pico.elf`、`Read_Pico.bin`、链接 map、逐步日志和 `result.json`。基线只有 ELF 与 BIN 均逐字节匹配 `relink-plan.json` 的正式候选 SHA-256 才成功；无需现存原构建目录。正式 BIN 为 4,160,944 字节，SHA-256：

`71c977630f11a970b7b16c9a7bc29d9e67ea19a0f823093fb17add25102ee76f`

## 修改和替换 epdiy

在工作副本编辑 `sources/epdiy/`，保持应用使用的 ABI 兼容，然后执行：

```sh
python3 relink.py --toolchain-bin "$TCBIN" --python "$PWD/.venv/bin/python" --output "$PWD/../relinked-modified" --rebuild-epdiy
```

该命令只重编列出的 14 个 epdiy 编译单元，按原顺序生成新的 `libepdiy.a`，随后与提供的应用对象及 SDK 库重链。不重编私有应用。库源和必要 SDK 头文件允许编辑；其他原始材料摘要仍强制校验。`relink-plan.json` 保留实际源、编译参数、逻辑路径映射与归档位置。原始库不改动的重编结果应与正式镜像原字节相同；修改后的镜像通常有不同摘要，工具会记录此事实。

修改后仍须自行验证修改涉及的行为。所提供镜像面向 ESP32-S3 / 16MB flash 及本产品对应板卡；运行期 120MHz flash/PSRAM 时序依赖匹配 Zbit 器件。此处 `elf2image` 的 `80m` 是原构建生成的镜像 flash 参数，不能据此修改运行期时序。

本工具只生成本地文件，不刷写设备。安装修改镜像时沿用同版本完整固件包的分区前提和用户刷写说明；应用槽起始地址以随附 `build/flasher_args.json`（当前 `0x10000`）为准。启用了 OTA rollback；不要在未知当前运行槽时机械覆盖应用地址，也不要把初始化 OTA 数据作为日常升级步骤。首次 FAT 分区迁移及数据备份要求见配套正式固件包说明。修改库后的真机功能、显示光学、功耗和栈余量未验证。

## 可核对的身份和许可

`materials-manifest.json` 列出每个材料文件的长度及 SHA-256。`verification.json` 记录生成与复现范围；它不代表真机验收。原始 build 与公开候选不是同一 ELF/BIN 摘要：归档对象调试信息净化及最终链接器去调试只改变非装载信息，应用 BIN 变化仅为 ELF 摘要和派生 XOR/SHA 校验；所有完整 ELF PT_LOAD、SHF_ALLOC 节、entry 和 ESP 镜像实际装载内容已核相等。

`APPLICATION-RELINK-PERMISSION.txt` 明确允许替换库后重组合、重链、安装以及调试修改所需的逆向。第三方许可证和版权声明见 `LICENSES/` 与 `license-provenance.json`。库和依赖各自许可证继续适用。
