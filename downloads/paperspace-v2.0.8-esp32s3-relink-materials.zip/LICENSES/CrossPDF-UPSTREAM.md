# CrossPDF 文字提取依赖

来源：[davemessew/CrossPDF](https://github.com/davemessew/CrossPDF)，固定提交 `a39adc83b8bae80d6c9e9f0d73c9ab9c6a8ed9cb`。
仅收录其 `test/pdf_extraction/CMakeLists.txt` 的 37 个 C++、2 个 C 生产单元及传递头；`sources.txt` 是本项目 CMake/native 共用的编译清单，`sources.json` 记录来源。未收录 Arduino/HAL、上游 UI 或测试实现。

根目录 `LICENSE` 保留 CrossPDF MIT 许可；`lib/uzlib/src/` 保留各文件原有 zlib 许可通知。其余原文件的许可/版权注释不变。

本地改动限定为文字重排适配：

- `PdfOwnedMemory.h`、`PdfPreparation.{h,cpp}`：显式所有者分配/释放回调，保持固定 overlay 不扩容，另分配有界的 512 字形与 CMap 记录表；支持真实文件名 fallback、文字模式。
- `PdfLimits.h`、`PdfPreparedContent.cpp`：独立表消费者使用对应容量，保留原物化 overlay 大小。
- `PdfFontMap.cpp`：完整存储必要映射；缺失或失败不猜替代字符；合法内置 simple encoding 仍正常解码。
- `PdfContentInterpreter.cpp`、`PdfPreparation.cpp`：错误 CMap、预算超限、无效/递归 Form、无法解码内容及无可读文字源页明确失败，禁止静默丢弃后段/页面成功。
- `PdfSemanticWriter.{h,cpp}`：可选 `preserveMappedText` 保留已映射文本、显式空白及标点；默认上游模式不变。文字模式不输出插图，不新增原页渲染/OCR 声明。

运行时 I/O、PSRAM、源只读与私有缓存路径隔离位于本目录外的 `pdf_engine.cpp`；完整 XHTML 仍由既有 EPUB 转换器输出 PBOOK。纯图片或无可读文字的页面（包括当前无法可靠识别的空白页）、加密和超限文件明确不支持。
